# Authored Character Robotics — reference implementation

A runnable implementation of the architecture in *"Authored Character Robotics: A Deterministic Architecture
for Expressive, Game-Governed Humanoid Robots"*: an immutable authored personality, a Game Rulebook that governs
all interaction, hardware-level safety vetoes, bounded memory, and offline skill refinement.

The robot is simulated (a Tonybot-class 17-DOF frame with PID-driven joints), so everything runs on a laptop.
`src/` is dependency-free ES2022 with no Node APIs, so it ports to Mikro.js / ESP32-S3 as the paper intends.

```bash
npm install          # tsx, typescript, @types/node
npm run demo         # guided tour of every layer
npm test             # 40 architecture-invariant tests
npm run typecheck
npm run test:firmware   # generates firmware/limits_generated.h, builds + runs the C++ safety-core tests
```

## Where each part of the paper lives

| Paper | Code |
|---|---|
| §4.2.1 Read-only Core Identity ("Bedrock Soul") | `src/mind/coreIdentity.ts` — conditional probability tables, deep-freeze, FNV-1a checksum, ROM image, boot-time verify. Characters: `src/mind/characters.ts` |
| §4.2.2 Simulation Engine (~1,000 candidates) | `src/mind/simulationEngine.ts`, `src/mind/primitives.ts` (parameterised motion-primitive library) |
| §4.2.3 Physics Proxy | `src/mind/physicsProxy.ts` — joint limits, servo speed, inverse-dynamics torque, ZMP stability |
| §2.2 Game Rulebook (HP, stamina, win/loss) | `src/game/rulebook.ts`; opponent + exchange resolution in `src/game/arena.ts` |
| §2.4 Combat pipeline, steps 1–8 | `Robot.decide()` / `execute()` / `learn()` in `src/robot.ts`; `npm run demo` prints each step |
| §4.1.1 Physical Safety Veto | `src/safety/veto.ts` |
| §4.1.2 Watchdog (50 ms) | `Watchdog` in `src/safety/safetyLayer.ts` (latched; hardware reset only) |
| §4.1.3 Default Survival Matrix | `src/safety/survival.ts` (imports only `spec.ts` — enforced by a test) |
| §4.1 in C++ (§5.1) | `firmware/safety_core.h`, tests in `firmware/test_safety_core.cpp`; limits generated from `src/spec.ts` |
| §4.3 Growth Layer: logging, Alignment Check, Memory Log, Rejection Bin, 40% cap, decay | `src/growth/growthLayer.ts` |
| §4.4 Sleep/Dive (PID micro-simulations, volatile dreams) | `src/growth/sleepDive.ts`, `src/motor.ts` |
| §3.5 Heartbeat / breathing / warmth | `src/haptics.ts` |
| §3 Frame (17 DOF, 17 kg·cm servos) | `src/spec.ts` |

## Guarantees the tests enforce

- The identity is deeply frozen; a tampered identity or ROM image fails the boot check.
- Decisions are deterministic: same inputs and seed give the same action (no `Math.random` anywhere).
- Memory's share of the final bias stays strictly under 40%, can't create behaviour outside the identity's support, and decays with age. The Rejection Bin can't influence anything.
- Sleep/Dive can only write PID gains, bounded to 0.25–4× factory, and wipes its dream buffer on wake. It never touches the identity or memory.
- Anything the Physics Proxy accepts, the hardware Veto also accepts.
- A stalled main core is overridden by the Survival Matrix within 60 ms, and only a hardware reset clears it.
- Unaffordable (stamina) actions are rejected by the Rulebook before they reach physics.

## Where the paper was ambiguous (decisions I made)

- **Candidate weights.** Identity probabilities become multipliers as `p × |support|`. Kaede's §2.4 example comes out ×2 parry/counter and ×0.5 aggressive, and feint/dynamic at ×0.75 rather than a neutral ×1, because the paper's weights don't form a normalised distribution.
- **Final score** = identity multiplier × situational fit (timing/zone/reach from spatial awareness) × Physics Proxy score. `counterBias` and `openSpaceBias` are two scalar traits on the identity (the paper's "Spatial Context" bias, plus a riposte preference).
- **`flee`** (§4.2.1) is folded into `dynamic` (retreat/backstep). **"Wrist angle"** (§2.4) becomes blade angle via shoulder-roll/elbow, since a 17-DOF frame has no wrists.
- The two characters are Kaede (defensive counter-fighter, the §2.4 example) and Ryuu (80% aggressive, the §4.2.1 example).

## Honest limitations

- **Physics is reduced-order.** Inertias, loads and CoM coefficients in `src/spec.ts` are estimates; identify them on the real frame before trusting stability margins. Toy-scale timings (swings of 400–900 ms) are a consequence of 17 kg·cm servos — the backflip is rejected, as §3.1 predicts.
- **Spatial perception is perfect** in the sim (the opponent's strike zone and timing are known). Real sensing noise will weaken the pipeline's timing advantage.
- **Style needs candidate density.** With ≥400 candidates both characters pick their signature style consistently; at ~150 a well-timed strike can be missing from the sample.
- **Sleep/Dive trades smoothness for accuracy.** In the demo, tracking accuracy rises (48% → 60%) while measured jerk rises too (309 → 433 rad/s³): the optimiser rides the gain bound. Tune the cost weights in `src/motor.ts` (`simulateTracking`) for your priorities.
- **Stock LX-series bus servos** run their own inner position loop, so the PID gains apply to a software tracking layer or to the torque-controlled actuators in §3.4.
- **Hardware seam:** `HardwareBus` (`src/hardware.ts`) is the interface for a real UART servo driver; only the simulator is implemented. The Survival Matrix gait is a visual placeholder, not a validated walking controller.
- The C++ safety logic is a hand port of the TS reference; only the limit tables are generated. Both are tested against the same scenarios, not against shared golden vectors.
