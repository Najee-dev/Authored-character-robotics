// Host-side tests for safety_core.h — mirrors the safety tests in test/architecture.test.ts.
//   npm run test:firmware
#undef NDEBUG
#include <cassert>
#include <cstdio>

#include "safety_core.h"

using namespace acr;

static Frame ready() {
  // Fight stance, same values as READY in src/spec.ts.
  Frame f;
  for (size_t j = 0; j < kNumJoints; ++j) f.deg[j] = kPoseStand[j];
  f.deg[L_HIP_PITCH] = f.deg[R_HIP_PITCH] = -10.0f;
  f.deg[L_KNEE] = f.deg[R_KNEE] = 20.0f;
  f.deg[L_ANKLE_PITCH] = f.deg[R_ANKLE_PITCH] = 29.5f;
  f.deg[R_SHOULDER_PITCH] = 70.0f;
  f.deg[R_ELBOW] = 80.0f;
  f.deg[R_SHOULDER_ROLL] = 15.0f;
  f.deg[L_SHOULDER_PITCH] = 20.0f;
  f.deg[L_SHOULDER_ROLL] = 25.0f;
  f.deg[L_ELBOW] = 60.0f;
  return f;
}

static Telemetry telem(const Frame& at) {
  Telemetry t{};
  t.angles = at;
  for (size_t j = 0; j < kNumJoints; ++j) t.temp_c[j] = 30.0f;
  return t;
}

static void test_veto() {
  Veto v;
  Violation out[8];
  const Frame r = ready();
  Telemetry t = telem(r);

  assert(v.check_frame(r, &r, 10.0f, &t, out, 8) == 0);

  Frame bad = r;
  bad.deg[R_ELBOW] = 150.0f;  // beyond the 140° hard stop
  assert(v.check_frame(bad, nullptr, 10.0f, nullptr, out, 8) == 1);
  assert(out[0].category == Category::Mechanical && out[0].joint == R_ELBOW);

  Frame fast = r;
  fast.deg[R_ELBOW] = 130.0f;  // 50° in 10 ms = 5000°/s
  assert(v.check_frame(fast, &r, 10.0f, nullptr, out, 8) == 1);

  Telemetry hot = telem(r);
  hot.temp_c[R_ELBOW] = 80.0f;
  assert(v.check_frame(r, &r, 10.0f, &hot, out, 8) == 1 && out[0].severity == Severity::Fatal);

  Telemetry tilted = telem(r);
  tilted.tilt_deg = 40.0f;
  assert(v.check_frame(r, &r, 10.0f, &tilted, out, 8) == 1 && out[0].category == Category::Stability);

  Telemetry strained = telem(r);
  strained.torque_nm[R_ELBOW] = 5.0f;
  assert(v.check_frame(r, &r, 10.0f, &strained, out, 8) == 1 && out[0].category == Category::PowerThermal);
}

static void test_watchdog() {
  Watchdog w;
  w.kick(100);
  assert(!w.poll(150));  // exactly 50 ms: still alive
  assert(w.poll(151));
  w.kick(152);  // software cannot revive it
  assert(w.poll(153));
  w.hardware_reset(200);
  assert(!w.poll(220));
  // wrap-around safety
  Watchdog wrap;
  wrap.kick(0xFFFFFFF0u);
  assert(!wrap.poll(0x00000010u));  // 32 ms across the wrap
  assert(wrap.poll(0x00000040u));
}

static void test_arbitration() {
  SafetyCore core;
  const Frame r = ready();
  const Telemetry t = telem(r);
  const SurvivalSensors s;
  Frame bad = r;
  bad.deg[R_ELBOW] = 200.0f;
  Frame out;

  core.heartbeat(10);
  assert(core.step(10, 10.0f, &r, t, s, out) == Source::Brain);
  // three consecutive blocked frames → Survival Matrix, latched
  core.heartbeat(20);
  assert(core.step(20, 10.0f, &bad, t, s, out) == Source::Hold);
  core.heartbeat(30);
  assert(core.step(30, 10.0f, &bad, t, s, out) == Source::Hold);
  core.heartbeat(40);
  assert(core.step(40, 10.0f, &bad, t, s, out) == Source::Survival);
  core.heartbeat(50);
  assert(core.step(50, 10.0f, &r, t, s, out) == Source::Survival);  // a good frame is now ignored
  assert(core.in_survival());
  core.hardware_reset(60);
  core.heartbeat(70);
  assert(core.step(70, 10.0f, &r, t, s, out) == Source::Brain);

  // watchdog path: silence for > 50 ms
  SafetyCore w;
  w.heartbeat(100);
  Source src = Source::Brain;
  for (uint32_t now = 110; now <= 160; now += 10) src = w.step(now, 10.0f, nullptr, t, s, out);
  assert(src == Source::Survival);  // tripped at 160 (60 ms since last heartbeat)
}

static void test_survival() {
  SurvivalMatrix m;
  Frame f;
  SurvivalSensors s;
  assert(m.step(s, 0, 10.0f, f) == SurvivalState::Idle);
  s.has_beacon = true;
  s.beacon_distance_m = 1.0f;
  assert(m.step(s, 10, 10.0f, f) == SurvivalState::Follow);
  s.beacon_distance_m = 5.0f;
  assert(m.step(s, 20, 10.0f, f) == SurvivalState::Idle);
  s.has_beacon = false;
  s.battery_pct = 10.0f;
  assert(m.step(s, 30, 10.0f, f) == SurvivalState::Charge);
  s.battery_pct = 100.0f;
  s.charger_detected = true;
  assert(m.step(s, 40, 10.0f, f) == SurvivalState::Charge);
  s.charger_detected = false;
  s.button_pressed = true;
  assert(m.step(s, 50, 10.0f, f) == SurvivalState::BasicDance);
  s.button_pressed = false;
  assert(m.step(s, 3000, 10.0f, f) == SurvivalState::BasicDance);
  assert(m.step(s, 7000, 10.0f, f) == SurvivalState::Idle);

  // hand-over is slew-limited to half the servo speed limit per tick
  SurvivalMatrix h;
  const Frame r = ready();
  h.seed(r);
  SurvivalSensors none;
  h.step(none, 0, 10.0f, f);
  for (size_t j = 0; j < kNumJoints; ++j) {
    assert(std::fabs(f.deg[j] - r.deg[j]) <= 0.5f * kMaxVelDegS[j] * 0.01f + 1e-4f);
  }
}

int main() {
  test_veto();
  test_watchdog();
  test_arbitration();
  test_survival();
  std::puts("safety_core: all firmware tests passed");
  return 0;
}
