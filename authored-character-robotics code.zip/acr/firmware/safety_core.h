// Safety core for the secondary ESP32-S3 core / separate MCU (paper §4.1, §5.1).
//
// Port of src/safety/*.ts. Header-only, no heap, no exceptions, no RTTI, no Arduino/ESP-IDF
// dependency — the host only supplies a millisecond clock and the main core's heartbeat.
// Limits come from limits_generated.h (generated from src/spec.ts).
//
// The main core can only PROPOSE frames. This code owns the servo bus.
#pragma once
#include <cmath>
#include <cstddef>
#include <cstdint>

#include "limits_generated.h"

namespace acr {

struct Frame {
  float deg[kNumJoints];
};

struct Telemetry {
  Frame angles;
  float torque_nm[kNumJoints];
  float temp_c[kNumJoints];
  float tilt_deg;
};

enum class Category : uint8_t { Mechanical, Stability, PowerThermal };
enum class Severity : uint8_t { Block, Fatal };

struct Violation {
  Category category;
  Severity severity;
  int8_t joint;  // -1 when not joint-specific
};

// ── Physical Safety Veto ────────────────────────────────────────────────────────────────────────────
class Veto {
 public:
  // Fills `out` with up to `cap` violations and returns how many were found (may exceed `cap`).
  size_t check_frame(const Frame& f, const Frame* prev, float dt_ms, const Telemetry* t, Violation* out,
                     size_t cap) const {
    size_t n = 0;
    auto push = [&](Category c, Severity s, int j) {
      if (n < cap) out[n] = Violation{c, s, static_cast<int8_t>(j)};
      ++n;
    };
    for (size_t j = 0; j < kNumJoints; ++j) {
      const float a = f.deg[j];
      if (!std::isfinite(a)) {
        push(Category::Mechanical, Severity::Fatal, static_cast<int>(j));
        continue;
      }
      if (a < kMinDeg[j] + kAngleMarginDeg || a > kMaxDeg[j] - kAngleMarginDeg)
        push(Category::Mechanical, Severity::Block, static_cast<int>(j));
      if (prev != nullptr && dt_ms > 0.0f) {
        const float vel = std::fabs(a - prev->deg[j]) / (dt_ms / 1000.0f);
        if (vel > kMaxVelDegS[j] * kVelocityTolerance) push(Category::Mechanical, Severity::Block, static_cast<int>(j));
      }
      if (t != nullptr) {
        if (std::fabs(t->torque_nm[j]) > kMaxTorqueNm[j] * 1.001f)
          push(Category::PowerThermal, Severity::Block, static_cast<int>(j));
        if (t->temp_c[j] >= kMaxTempC) push(Category::PowerThermal, Severity::Fatal, static_cast<int>(j));
      }
    }
    // Static CoM envelope (generous: only unrecoverable states trip it).
    constexpr float kDeg2Rad = 0.017453292519943295f;
    float cx = 0.0f, cy = 0.0f;
    for (size_t j = 0; j < kNumJoints; ++j) {
      cx += kComX[j] * f.deg[j] * kDeg2Rad;
      cy += kComY[j] * f.deg[j] * kDeg2Rad;
    }
    if (std::fabs(cx) > kHalfLengthM * kStabilityEnvelopeScale || std::fabs(cy) > kHalfWidthM * kStabilityEnvelopeScale)
      push(Category::Stability, Severity::Block, -1);
    if (t != nullptr && t->tilt_deg >= kMaxTiltDeg) push(Category::Stability, Severity::Fatal, -1);
    return n;
  }
};

// ── Hardware watchdog (software model; on silicon use the MCU's WDT + a GPIO heartbeat line) ───────
class Watchdog {
 public:
  void kick(uint32_t now_ms) {
    if (!tripped_) last_ms_ = now_ms;
  }
  bool poll(uint32_t now_ms) {
    // unsigned subtraction is wrap-safe
    if (!tripped_ && static_cast<float>(now_ms - last_ms_) > kWatchdogTimeoutMs) tripped_ = true;
    return tripped_;
  }
  void hardware_reset(uint32_t now_ms) {
    tripped_ = false;
    last_ms_ = now_ms;
  }
  bool tripped() const { return tripped_; }

 private:
  uint32_t last_ms_ = 0;
  bool tripped_ = false;
};

// ── Default Survival Matrix ─────────────────────────────────────────────────────────────────────────
enum class SurvivalState : uint8_t { Idle, Follow, Charge, BasicDance };

struct SurvivalSensors {
  float battery_pct = 100.0f;
  bool charger_detected = false;
  bool has_beacon = false;
  float beacon_bearing_deg = 0.0f;
  float beacon_distance_m = 0.0f;
  bool button_pressed = false;
};

class SurvivalMatrix {
 public:
  SurvivalMatrix() { seed_from(kPoseStand); }

  void seed(const Frame& f) { out_ = f; }

  SurvivalState step(const SurvivalSensors& s, uint32_t now_ms, float dt_ms, Frame& out) {
    if (s.button_pressed && dance_until_ms_ <= now_ms) {
      dance_until_ms_ = now_ms + kDanceMs;
      dancing_ = true;
    }
    if (dancing_ && now_ms >= dance_until_ms_) dancing_ = false;
    const bool beacon_near = s.has_beacon && s.beacon_distance_m >= 0.25f && s.beacon_distance_m <= 2.0f;

    if (s.charger_detected || s.battery_pct <= kLowBatteryPct) state_ = SurvivalState::Charge;
    else if (dancing_) state_ = SurvivalState::BasicDance;
    else if (beacon_near) state_ = SurvivalState::Follow;
    else state_ = SurvivalState::Idle;

    float target[kNumJoints];
    const float ph = static_cast<float>(now_ms) / 1000.0f * 6.2831853f;
    switch (state_) {
      case SurvivalState::Charge:
        if (s.charger_detected) copy(target, kPoseSit);
        else if (beacon_near) gait(target, ph, s.beacon_bearing_deg);
        else copy(target, kPoseStand);
        break;
      case SurvivalState::Follow:
        gait(target, ph, s.beacon_bearing_deg);
        break;
      case SurvivalState::BasicDance:
        dance(target, ph);
        break;
      default:
        copy(target, kPoseStand);
        target[L_HIP_PITCH] = -2.0f + 1.5f * std::sin(ph / 4.0f);
        target[R_HIP_PITCH] = target[L_HIP_PITCH];
    }
    // Slew limit: half the servo speed limit per tick so hand-over never slams the joints.
    for (size_t j = 0; j < kNumJoints; ++j) {
      const float max_step = 0.5f * kMaxVelDegS[j] * (dt_ms / 1000.0f);
      float d = target[j] - out_.deg[j];
      d = d > max_step ? max_step : (d < -max_step ? -max_step : d);
      out_.deg[j] += d;
    }
    out = out_;
    return state_;
  }

  SurvivalState state() const { return state_; }

 private:
  static constexpr float kLowBatteryPct = 15.0f;
  static constexpr uint32_t kDanceMs = 6000;

  static void copy(float* dst, const float* src) {
    for (size_t j = 0; j < kNumJoints; ++j) dst[j] = src[j];
  }
  void seed_from(const float* p) {
    for (size_t j = 0; j < kNumJoints; ++j) out_.deg[j] = p[j];
  }
  // Placeholder visual gait — NOT a validated walking controller.
  static void gait(float* t, float ph, float bearing) {
    copy(t, kPoseStand);
    const float s = std::sin(1.2f * ph);
    t[L_HIP_PITCH] = -12.0f + 14.0f * s;
    t[R_HIP_PITCH] = -12.0f - 14.0f * s;
    t[L_KNEE] = 22.0f + 12.0f * (s > 0.0f ? s : 0.0f);
    t[R_KNEE] = 22.0f + 12.0f * (-s > 0.0f ? -s : 0.0f);
    t[L_ANKLE_PITCH] = 10.0f;
    t[R_ANKLE_PITCH] = 10.0f;
    t[HEAD_YAW] = bearing < -60.0f ? -60.0f : (bearing > 60.0f ? 60.0f : bearing);
  }
  static void dance(float* t, float ph) {
    copy(t, kPoseStand);
    t[R_SHOULDER_PITCH] = 90.0f + 40.0f * std::sin(ph);
    t[L_SHOULDER_PITCH] = 90.0f - 40.0f * std::sin(ph);
    t[R_SHOULDER_ROLL] = t[L_SHOULDER_ROLL] = 40.0f;
    t[R_ELBOW] = t[L_ELBOW] = 60.0f;
    t[L_HIP_ROLL] = t[R_HIP_ROLL] = 8.0f * std::sin(ph);
    t[L_KNEE] = t[R_KNEE] = 12.0f;
    t[L_HIP_PITCH] = t[R_HIP_PITCH] = -6.0f;
    t[L_ANKLE_PITCH] = t[R_ANKLE_PITCH] = 5.0f;
    t[HEAD_YAW] = 25.0f * std::sin(ph / 2.0f);
  }

  Frame out_{};
  SurvivalState state_ = SurvivalState::Idle;
  uint32_t dance_until_ms_ = 0;
  bool dancing_ = false;
};

// ── Arbitration: brain → veto → servo bus, else Survival Matrix ─────────────────────────────────────
enum class Source : uint8_t { Brain, Hold, Survival };

class SafetyCore {
 public:
  // The main core pulses this (GPIO / inter-core queue) independent of whether it has a frame ready.
  void heartbeat(uint32_t now_ms) { wdt_.kick(now_ms); }

  // `proposed` may be nullptr (main core silent). `out` is what to write to the servo bus.
  Source step(uint32_t now_ms, float dt_ms, const Frame* proposed, const Telemetry& t, const SurvivalSensors& s,
              Frame& out) {
    if (!have_last_) {
      last_safe_ = t.angles;
      have_last_ = true;
    }
    if (wdt_.poll(now_ms) || latched_) return survive(now_ms, dt_ms, s, out);
    if (proposed == nullptr) {
      out = last_safe_;
      return Source::Hold;
    }
    Violation v[8];
    const size_t n = veto_.check_frame(*proposed, &last_safe_, dt_ms, &t, v, 8);
    if (n == 0) {
      blocks_ = 0;
      last_safe_ = *proposed;
      out = *proposed;
      return Source::Brain;
    }
    ++blocks_;
    bool fatal = false;
    for (size_t i = 0; i < n && i < 8; ++i) fatal = fatal || v[i].severity == Severity::Fatal;
    if (fatal || blocks_ >= kMaxConsecutiveBlocks) {
      latched_ = true;
      return survive(now_ms, dt_ms, s, out);
    }
    out = last_safe_;
    return Source::Hold;
  }

  // Hardware reset line — the only way back from survival.
  void hardware_reset(uint32_t now_ms) {
    wdt_.hardware_reset(now_ms);
    latched_ = false;
    blocks_ = 0;
    seeded_ = false;
    have_last_ = false;
  }

  bool in_survival() const { return latched_ || wdt_.tripped(); }
  SurvivalState survival_state() const { return survival_.state(); }

 private:
  Source survive(uint32_t now_ms, float dt_ms, const SurvivalSensors& s, Frame& out) {
    if (!seeded_) {
      survival_.seed(last_safe_);
      seeded_ = true;
    }
    survival_.step(s, now_ms, dt_ms, out);
    last_safe_ = out;
    return Source::Survival;
  }

  Veto veto_;
  Watchdog wdt_;
  SurvivalMatrix survival_;
  Frame last_safe_{};
  bool have_last_ = false;
  bool seeded_ = false;
  bool latched_ = false;
  int blocks_ = 0;
};

}  // namespace acr
