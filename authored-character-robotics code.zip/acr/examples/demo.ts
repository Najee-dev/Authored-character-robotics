/**
 * End-to-end tour of the Authored Character Robotics architecture.
 *   npm run demo
 */
import { Robot, type ClassCounts, type Decision } from '../src/robot';
import { SimulatedHardware } from '../src/hardware';
import { factoryMotorParams, type MotorParams } from '../src/motor';
import { READY } from '../src/spec';
import { ScriptedOpponent, resolveExchange } from '../src/game/arena';
import { KAEDE, KAEDE_SPEC, RYUU } from '../src/mind/characters';
import { loadRomImage, toRomImage, type Distribution } from '../src/mind/coreIdentity';
import { instantiate, PRIMITIVES, type Candidate } from '../src/mind/primitives';
import { NO_SENSORS } from '../src/safety/survival';

const hr = (t: string) => console.log(`\n━━ ${t} ${'━'.repeat(Math.max(0, 72 - t.length))}`);
const pct = (n: number) => `${(n * 100).toFixed(0)}%`;
const counts = (c: ClassCounts) => Object.entries(c).map(([k, v]) => `${k} ${v}`).join(' · ') || '—';
const dist = (d: Distribution) => Object.entries(d).map(([k, v]) => `${k} ${(v as number).toFixed(3)}`).join(', ');

function newRobot(identity = KAEDE, opts: { seed?: number; candidates?: number; motor?: MotorParams } = {}): Robot {
  const motor = opts.motor ?? factoryMotorParams();
  return new Robot({ identity, hardware: new SimulatedHardware(motor, READY), motor, seed: opts.seed ?? 7, candidates: opts.candidates });
}

function describe(c: Candidate): string {
  return `${c.primitive}${c.counter ? '+riposte' : ''} (${c.cls}, peak ${c.peakMs} ms, stamina ${c.staminaCost.toFixed(1)})`;
}

function playMatch(robot: Robot, seed: number, log: boolean, maxExchanges = 12): void {
  const opp = new ScriptedOpponent(seed);
  for (let i = 0; robot.rules.status === 'running' && i < maxExchanges; i++) {
    const { map, strike } = opp.next();
    const d = robot.decide('Fight', map, i);
    if (!d.chosen) {
      if (log) console.log(`  #${i} no affordable action — resting (stamina ${robot.rules.stamina.toFixed(0)})`);
      robot.rules.tick(1500);
      continue;
    }
    const c = d.chosen.candidate;
    const exec = robot.execute(c);
    const outcome = resolveExchange(c, map, strike, robot.rules.cfg);
    robot.learn(d, exec, outcome);
    if (log) {
      console.log(
        `  #${i} strike ${strike.zone}@${strike.impactMs.toFixed(0)}ms → ${describe(c)}\n` +
        `      ${outcome.tags.join(', ')} | HP robot ${robot.rules.hp} / foe ${robot.rules.opponentHp} | stamina ${robot.rules.stamina.toFixed(0)} | status ${robot.rules.status}`,
      );
    }
  }
}

function pipeline(d: Decision): void {
  const t = d.trace;
  console.log(`Step 1  Rulebook command: ${t.command}`);
  console.log(`Step 2  Simulation Engine generated ${Object.values(t.generated).reduce((a, b) => a + (b ?? 0), 0)} candidates: ${counts(t.generated)}`);
  console.log(`Step 3  Core Identity "${KAEDE.spec.name}" bias for context "${t.contextKey}":`);
  console.log(`          ${dist(t.core)}`);
  console.log(`          → candidate weight ×: ${Object.entries(t.multipliers).map(([k, v]) => `${k} ${v}`).join(', ')}   (core ${pct(t.coreShare)} / memory ${pct(t.memoryShare)})`);
  console.log(`Step 4  Spatial awareness: opponent strike expected in ${t.threat?.impactMs.toFixed(0)} ms, zone ${t.threat?.zone}`);
  console.log(`Step 5  Physics Proxy rejected: ${counts(t.physicsRejected)}   (reasons: ${Object.entries(t.rejectionReasons).map(([k, v]) => `${k} ${v}`).join(', ')})`);
  console.log(`        survivors: ${counts(t.survivors)}`);
  console.log(`Step 6  Top candidates by weight × situational fit × physics score:`);
  t.top.slice(0, 3).forEach((s, i) => console.log(`          ${i + 1}. ${describe(s.candidate)}  final ${s.final.toFixed(2)} = ${s.multiplier.toFixed(2)} × fit ${s.fit.toFixed(2)} × phys ${s.physics.score.toFixed(2)}`));
  console.log(`Step 7  Physical Safety Veto: ${t.vetoRejected} rejected before the chosen plan passed`);
}

// ─────────────────────────────────────────────────────────────────────────────────────────────────────
hr('1. Bedrock Soul: burned, checksummed, tamper-evident');
const rom = toRomImage(KAEDE);
console.log(`ROM image: ${rom.length} bytes, footer ${rom.slice(rom.lastIndexOf('#'))}`);
console.log(`Round-trip load OK: ${loadRomImage(rom).checksum === KAEDE.checksum}`);
try { loadRomImage(rom.replace('"defensive":0.5', '"defensive":0.1')); } catch (e) { console.log(`Tampered image rejected: ${(e as Error).message}`); }
try { (KAEDE.spec.dispositions['combat/close/armed'] as Record<string, number>).defensive = 0.01; } catch (e) { console.log(`In-memory mutation blocked: ${(e as Error).constructor.name}`); }
console.log(`Backstory (documentation only): "${KAEDE_SPEC.backstory[0]}"`);

hr('2. The combat pipeline, step by step (paper §2.4)');
{
  const r = newRobot(KAEDE, { seed: 7 });
  const { map, strike } = new ScriptedOpponent(3).next();
  const d = r.decide('Fight', map, 0);
  pipeline(d);
  const exec = r.execute(d.chosen!.candidate);
  const out = resolveExchange(d.chosen!.candidate, map, strike, r.rules.cfg);
  const al = r.learn(d, exec, out)!;
  console.log(`Step 8  Executed (${exec.sources.brain} brain frames, ${exec.blockedFrames} blocked) → ${out.tags.join(', ')}`);
  console.log(`        Alignment Check: similarity ${al.similarity.toFixed(2)} → ${al.compatible ? 'Cumulative Memory Log' : 'Rejection Bin'}`);
}

hr('3. A full match as Ryuu: first to 3 hits, HP + stamina accounting (Game Rulebook)');
{
  const r = newRobot(RYUU, { seed: 11, candidates: 400 });
  playMatch(r, 21, true);
  const h = r.rules.hits;
  console.log(`Result: ${r.rules.status.toUpperCase()}  (hits landed ${h.robot}, taken ${h.opponent}) | memory ${r.growth.memorySize} entries, bin ${r.growth.bin.count}`);
  console.log(`Haptics now: ${JSON.stringify(r.haptics('Fight'))}`);
}

hr('4. Same engine, different soul (Kaede vs Ryuu, 8 identical situations)');
for (const id of [KAEDE, RYUU]) {
  const tally: ClassCounts = {};
  const r = newRobot(id, { seed: 5, candidates: 300 });
  const opp = new ScriptedOpponent(99);
  for (let i = 0; i < 8; i++) {
    const { map } = opp.next();
    const d = r.decide('Fight', map, i);
    if (d.chosen) tally[d.chosen.candidate.cls] = (tally[d.chosen.candidate.cls] ?? 0) + 1;
  }
  console.log(`  ${id.spec.name.padEnd(6)} chose: ${counts(tally)}`);
}

hr('5. Rulebook stamina gate: unaffordable actions never reach the planner');
{
  const r = newRobot(KAEDE, { seed: 7, candidates: 400 });
  r.rules.stamina = 7;
  const { map } = new ScriptedOpponent(3).next();
  const d = r.decide('Fight', map, 0);
  console.log(`  stamina 7 → rejected by Rulebook: ${counts(d.trace.staminaRejected)}`);
  console.log(`  chose: ${d.chosen ? describe(d.chosen.candidate) : 'nothing'}`);
}

hr('6. Safety layer: veto, watchdog, survival matrix');
{
  const r = newRobot(KAEDE, { seed: 7, candidates: 200 });
  const bad = instantiate(PRIMITIVES.find((p) => p.id === 'pivot_spin')!, { speed: 1, reach: 1, aim: 0, delayMs: 0, counter: false }, 0);
  console.log(`  Veto on a plan with hip-yaw 60° (hard stop 45°): ${r.safety.veto.checkTrajectory(bad.trajectory)[0]?.detail}`);
  const flip = instantiate(PRIMITIVES.find((p) => p.id === 'backflip')!, { speed: 1, reach: 1, aim: 0, delayMs: 0, counter: false }, 1);
  console.log(`  Veto on a backflip plan: ${r.safety.veto.checkTrajectory(flip.trajectory).length} violations (servos cannot do it)`);
  const { map } = new ScriptedOpponent(3).next();
  const d = r.decide('Fight', map, 0);
  const res = r.execute(d.chosen!.candidate, { stallBrainAtMs: 200 }); // main core hangs 200 ms in
  console.log(`  Main core stalls at 200 ms → watchdog tripped: ${r.safety.watchdog.tripped}; frames from ${JSON.stringify(res.sources)}; cause ${res.abortedBy}`);
  console.log(`  Survival Matrix now in state "${r.safety.survival.state}" — no cognitive access, latched until hardware reset`);
  r.hardwareReset();
  console.log(`  After hardware reset, watchdog tripped: ${r.safety.watchdog.tripped}`);
}

hr('7. Sleep/Dive: skills improve, personality does not');
{
  const probeParams = { speed: 1, reach: 1, aim: 0, delayMs: 0, counter: true };
  const probe = (motor: MotorParams) => {
    const r = newRobot(KAEDE, { motor, candidates: 50 });
    return r.execute(instantiate(PRIMITIVES.find((p) => p.id === 'parry_high')!, probeParams, 0)).metrics;
  };
  const before = probe(factoryMotorParams());
  const r = newRobot(KAEDE, { seed: 31, candidates: 300 });
  const idBefore = r.identity.checksum;
  const styleBefore = r.decide('Fight', new ScriptedOpponent(8).next().map, 0).trace.core;
  for (let day = 1; day <= 3; day++) {
    playMatch(r, 100 + day, false, 6);
    r.rules.stamina = r.rules.cfg.maxStamina; r.rules.hp = r.rules.cfg.maxHp; r.rules.status = 'running';
    r.sensors = { ...NO_SENSORS, chargerDetected: true }; // docked → Sleep/Dive may run
    const rep = r.sleep(day);
    console.log(`  night ${day}: replayed ${rep.replayed} motions, ${rep.microSimulations} micro-simulations, ${rep.jointsImproved} joints improved, cost ${rep.costBefore.toFixed(2)} → ${rep.costAfter.toFixed(2)}, ${rep.dreamCharsWiped} chars of dream wiped`);
    r.sensors = NO_SENSORS;
    r.clockMs += 24 * 3600 * 1000;
  }
  const after = probe(r.motor);
  console.log(`  Same parry, before → after: tracking accuracy ${pct(before.timingAccuracy)} → ${pct(after.timingAccuracy)}, jerk ${before.jerk.toFixed(0)} → ${after.jerk.toFixed(0)} rad/s³`);
  const bias = r.growth.blendedBias('combat/close/armed', styleBefore, r.clockMs);
  console.log(`  Core Identity checksum unchanged: ${r.identity.checksum === idBefore}`);
  console.log(`  Behavioural drift: core share ${pct(bias.coreShare)} (floor 60%), memory share ${pct(bias.memoryShare)} (cap 40%)`);
  console.log(`  Blended bias: ${dist(bias.dist)}`);
}
