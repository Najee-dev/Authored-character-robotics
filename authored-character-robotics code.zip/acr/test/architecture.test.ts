import test, { describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { JOINTS, JOINT_SPECS, READY, SAFETY_LIMITS, STAND, makePose } from '../src/spec';
import { Rng } from '../src/motion';
import { SimulatedHardware } from '../src/hardware';
import { GAIN_BOUNDS, factoryGains, factoryMotorParams } from '../src/motor';
import { Robot } from '../src/robot';
import { GameRulebook } from '../src/game/rulebook';
import { ScriptedOpponent, resolveExchange } from '../src/game/arena';
import { heartbeatPulse, hapticsFor } from '../src/haptics';
import { KAEDE, KAEDE_SPEC, RYUU } from '../src/mind/characters';
import { burnIdentity, loadRomImage, toRomImage, verifyIdentity, type BurnedIdentity } from '../src/mind/coreIdentity';
import { evaluate } from '../src/mind/physicsProxy';
import { PRIMITIVES, instantiate, sampleParams } from '../src/mind/primitives';
import { PhysicalSafetyVeto } from '../src/safety/veto';
import { SafetyLayer, Watchdog } from '../src/safety/safetyLayer';
import { NO_SENSORS, SurvivalMatrix } from '../src/safety/survival';
import { GrowthLayer, alignmentScore, type ActionRecord } from '../src/growth/growthLayer';
import { sleepDive } from '../src/growth/sleepDive';

const params = { speed: 1, reach: 1, aim: 0, delayMs: 0, counter: false };
const prim = (id: string) => PRIMITIVES.find((p) => p.id === id)!;

function robot(identity: BurnedIdentity = KAEDE, candidates = 150, seed = 7): Robot {
  const motor = factoryMotorParams();
  return new Robot({ identity, hardware: new SimulatedHardware(motor, READY), motor, seed, candidates });
}

const record = (cls: ActionRecord['cls'], atMs = 0, success = true): ActionRecord => ({
  atMs, contextKey: 'combat/close/armed', cls, primitive: 'x', success,
  metrics: { jerk: 0, torqueEfficiency: 1, timingAccuracy: 1 },
});
const KEY = 'combat/close/armed';
const KAEDE_CORE = KAEDE.spec.dispositions[KEY];

describe('Core Identity (Bedrock Soul)', () => {
  test('is deeply frozen and verifiable', () => {
    verifyIdentity(KAEDE);
    assert.throws(() => { (KAEDE.spec.dispositions[KEY] as Record<string, number>).defensive = 0.9; }, TypeError);
    assert.throws(() => { (KAEDE as { checksum: string }).checksum = 'x'; }, TypeError);
  });
  test('tampering is detected at boot', () => {
    const forged = { spec: { ...KAEDE.spec, openSpaceBias: 0.1 }, checksum: KAEDE.checksum };
    assert.throws(() => verifyIdentity(forged), /integrity/);
    assert.throws(() => robot(forged as BurnedIdentity), /integrity/);
  });
  test('rejects distributions that do not sum to 1', () => {
    assert.throws(() => burnIdentity({ ...KAEDE_SPEC, dispositions: { combat: { defensive: 0.5, aggressive: 0.2 } } }), /sums to/);
  });
  test('ROM image round-trips and detects corruption', () => {
    const img = toRomImage(KAEDE);
    assert.equal(loadRomImage(img).checksum, KAEDE.checksum);
    assert.throws(() => loadRomImage(img.replace('0.5', '0.4')), /checksum/);
  });
  test('identity checksum is stable across builds of the same spec', () => {
    assert.equal(burnIdentity(KAEDE_SPEC).checksum, KAEDE.checksum);
  });
});

describe('Game Rulebook', () => {
  test('stamina gate rejects unaffordable actions; regen is capped', () => {
    const r = new GameRulebook();
    assert.equal(r.admit(30).ok, true);
    r.spend(90);
    assert.deepEqual(r.admit(30), { ok: false, reason: 'stamina' });
    r.tick(60_000);
    assert.equal(r.stamina, r.cfg.maxStamina);
  });
  test('win / loss / defeat conditions', () => {
    const hit = { robotHit: true, takenHit: false, dealt: 10, taken: 0, tags: [] };
    const taken = { robotHit: false, takenHit: true, dealt: 0, taken: 12, tags: [] };
    const w = new GameRulebook();
    for (let i = 0; i < 3; i++) w.apply(hit);
    assert.equal(w.status, 'won');
    const l = new GameRulebook();
    for (let i = 0; i < 3; i++) l.apply(taken);
    assert.equal(l.status, 'lost');
    const d = new GameRulebook({ ...l.cfg, win: [{ type: 'last_standing' }] });
    d.apply({ ...taken, taken: 100 });
    assert.equal(d.status, 'defeated');
    assert.deepEqual(d.admit(1), { ok: false, reason: 'match_over' });
    const t = new GameRulebook({ ...l.cfg, win: [{ type: 'time_limit', ms: 5000 }] });
    t.apply(hit);
    t.tick(5000);
    assert.equal(t.status, 'won');
  });
});

describe('Physics Proxy', () => {
  test('a backflip is infeasible on 17 kg·cm servos (paper §3.1)', () => {
    const v = evaluate(instantiate(prim('backflip'), params, 0).trajectory);
    assert.equal(v.feasible, false);
    assert.ok(v.reasons.some((r) => r.startsWith('velocity')));
  });
  test('hip-yaw beyond the hard stop is rejected', () => {
    const v = evaluate(instantiate(prim('pivot_spin'), params, 0).trajectory);
    assert.ok(v.reasons.some((r) => r.startsWith('joint_limit:l_hip_yaw')));
  });
  test('a gentle probe is feasible', () => {
    assert.equal(evaluate(instantiate(prim('probe_thrust'), params, 0).trajectory).feasible, true);
  });
  test('anything the Proxy accepts, the hardware Veto also accepts', () => {
    const rng = new Rng(123);
    const veto = new PhysicalSafetyVeto();
    let accepted = 0;
    for (let i = 0; i < 400; i++) {
      const def = PRIMITIVES[i % PRIMITIVES.length];
      const c = instantiate(def, sampleParams(def, rng), i);
      if (evaluate(c.trajectory).feasible) {
        accepted++;
        assert.deepEqual(veto.checkTrajectory(c.trajectory), [], `${c.primitive} #${i}`);
      }
    }
    assert.ok(accepted > 100);
  });
});

describe('Safety layer', () => {
  const veto = new PhysicalSafetyVeto();
  const telem = (over: Partial<{ torque: number; temp: number; tilt: number }> = {}) => ({
    angles: READY,
    torquesNm: makePose({ r_elbow: over.torque ?? 0 }),
    tempsC: makePose({ r_elbow: over.temp ?? 30 }),
    tiltDeg: over.tilt ?? 0,
  });

  test('veto: joint hard stop, speed, torque, thermal, tilt', () => {
    assert.equal(veto.checkFrame({ ...READY, r_elbow: 150 }, null, 10, null)[0].category, 'mechanical');
    assert.match(veto.checkFrame({ ...READY, r_elbow: 130 }, READY, 10, null)[0].detail, /°\/s/);
    assert.equal(veto.checkFrame(READY, READY, 10, telem({ torque: 5 }))[0].category, 'power_thermal');
    assert.equal(veto.checkFrame(READY, READY, 10, telem({ temp: 80 }))[0].severity, 'fatal');
    assert.equal(veto.checkFrame(READY, READY, 10, telem({ tilt: 40 }))[0].severity, 'fatal');
    assert.deepEqual(veto.checkFrame(READY, READY, 10, telem()), []);
  });
  test('veto does not reject for game "dangerousness": dynamic takedown frames pass', () => {
    const c = instantiate(prim('takedown_sweep'), params, 0);
    assert.deepEqual(veto.checkTrajectory(c.trajectory), []);
  });

  test('watchdog trips after 50 ms of silence, and only a hardware reset clears it', () => {
    const w = new Watchdog();
    w.kick(100);
    assert.equal(w.poll(150), false); // exactly 50 ms: still alive
    assert.equal(w.poll(151), true);
    w.kick(152); // main-core software cannot revive it
    assert.equal(w.poll(153), true);
    w.hardwareReset(200);
    assert.equal(w.poll(220), false);
  });

  test('3 consecutive blocked frames, or any fatal one, hand control to the Survival Matrix', () => {
    const s = new SafetyLayer();
    const bad = { ...READY, r_elbow: 200 };
    const t = { ...telem(), angles: READY };
    const out = [1, 2, 3].map((k) => (s.heartbeat(k * 10), s.arbitrate(k * 10, 10, bad, t, NO_SENSORS)));
    assert.deepEqual(out.map((o) => o.source), ['hold', 'hold', 'survival']);
    assert.equal(out[2].cause, 'veto_repeated');
    // latched: a perfectly good frame is now ignored
    s.heartbeat(40);
    assert.equal(s.arbitrate(40, 10, READY, t, NO_SENSORS).source, 'survival');
    s.hardwareReset(50);
    s.heartbeat(60);
    assert.equal(s.arbitrate(60, 10, READY, t, NO_SENSORS).source, 'brain');
  });

  test('survival matrix states follow raw sensors only', () => {
    const m = new SurvivalMatrix();
    const step = (s: Partial<typeof NO_SENSORS>, now: number) => m.step({ ...NO_SENSORS, ...s }, now, 10).state;
    assert.equal(step({}, 0), 'Idle');
    assert.equal(step({ beacon: { bearingDeg: 10, distanceM: 1 } }, 10), 'Follow');
    assert.equal(step({ beacon: { bearingDeg: 10, distanceM: 5 } }, 20), 'Idle');
    assert.equal(step({ batteryPct: 10 }, 30), 'Charge');
    assert.equal(step({ chargerDetected: true }, 40), 'Charge');
    assert.equal(step({ buttonPressed: true }, 50), 'BasicDance');
    assert.equal(step({}, 3000), 'BasicDance');
    assert.equal(step({}, 7000), 'Idle');
  });
  test('survival matrix hand-over is slew-limited', () => {
    const m = new SurvivalMatrix();
    m.seed(READY);
    const a = m.step(NO_SENSORS, 0, 10).pose;
    for (const j of JOINTS) assert.ok(Math.abs(a[j] - READY[j]) <= 0.5 * JOINT_SPECS[j].maxVelDegS * 0.01 + 1e-9);
  });
  test('survival matrix has no import path into the cognitive stack', () => {
    const src = readFileSync(new URL('../src/safety/survival.ts', import.meta.url), 'utf8');
    const imports = [...src.matchAll(/from '([^']+)'/g)].map((m) => m[1]);
    assert.deepEqual(imports, ['../spec']);
  });
});

describe('Decision pipeline', () => {
  const scenario = () => new ScriptedOpponent(3).next();

  test('generates the §2.4 candidate mix and Kaede’s ×2 / ×0.5 weights', () => {
    const { map } = scenario();
    const d = new Robot({ identity: KAEDE, hardware: new SimulatedHardware(factoryMotorParams(), READY), candidates: 1000, seed: 7 }).decide('Fight', map, 0);
    assert.deepEqual(d.trace.generated, { aggressive: 300, defensive: 400, feint: 200, dynamic: 100 });
    assert.equal(d.trace.multipliers.defensive, 2);
    assert.equal(d.trace.multipliers.aggressive, 0.5);
    assert.equal(d.trace.contextKey, 'combat/close/armed');
  });
  test('the soul decides the style: Kaede parries, Ryuu strikes', () => {
    const opp = new ScriptedOpponent(42);
    for (let i = 0; i < 4; i++) {
      const { map } = opp.next();
      assert.equal(robot(KAEDE, 500).decide('Fight', map, i).chosen!.candidate.cls, 'defensive');
      assert.equal(robot(RYUU, 500).decide('Fight', map, i).chosen!.candidate.cls, 'aggressive');
    }
  });
  test('fully deterministic: same inputs → identical decision', () => {
    const { map } = scenario();
    const a = robot().decide('Fight', map, 3).chosen!;
    const b = robot().decide('Fight', map, 3).chosen!;
    assert.equal(a.candidate.id, b.candidate.id);
    assert.equal(a.final, b.final);
    assert.deepEqual(a.candidate.trajectory, b.candidate.trajectory);
  });
  test('unaffordable candidates are rejected by the Rulebook before physics', () => {
    const { map } = scenario();
    const r = robot();
    r.rules.stamina = 7;
    const d = r.decide('Fight', map, 0);
    assert.ok(Object.values(d.trace.staminaRejected).reduce((a, b) => a + (b ?? 0), 0) > 0);
    assert.ok(d.chosen!.candidate.staminaCost <= 7);
  });
  test('no action after the match is over', () => {
    const r = robot();
    r.rules.status = 'won';
    assert.equal(r.decide('Fight', scenario().map, 0).chosen, null);
  });
  test('Greet uses the social table', () => {
    const r = robot(KAEDE);
    const d = r.decide('Greet', { friendly: { distanceM: 0.5 }, walls: { front: 2, back: 2, left: 2, right: 2 }, poseStable: true }, 0);
    assert.equal(d.trace.contextKey, 'social/friendly');
    assert.ok(['warm', 'teasing', 'indifferent'].includes(d.chosen!.candidate.cls));
    const exec = r.execute(d.chosen!.candidate); // settles from fight stance, then performs the gesture
    assert.equal(exec.completed, true);
  });
});

describe('Execution through the safety layer', () => {
  test('a normal plan plays out entirely from brain frames', () => {
    const r = robot();
    const { map } = new ScriptedOpponent(3).next();
    const res = r.execute(r.decide('Fight', map, 0).chosen!.candidate);
    assert.equal(res.completed, true);
    assert.equal(res.sources.survival, 0);
    assert.equal(res.blockedFrames, 0);
    assert.ok(res.metrics.timingAccuracy > 0.3);
  });
  test('a stalled main core is overridden by the watchdog within 60 ms', () => {
    const r = robot();
    const { map } = new ScriptedOpponent(3).next();
    const res = r.execute(r.decide('Fight', map, 0).chosen!.candidate, { stallBrainAtMs: 200 });
    assert.equal(res.completed, false);
    assert.equal(res.abortedBy, 'watchdog');
    assert.equal(res.sources.brain, 20);
    assert.equal(res.sources.hold, 5);
    assert.equal(r.safety.watchdog.tripped, true);
    r.hardwareReset();
    assert.equal(r.safety.watchdog.tripped, false);
  });
  test('a Kaede match is won under the Rulebook; every action is routed by the Alignment Check', () => {
    const r = robot(KAEDE, 200, 11);
    const opp = new ScriptedOpponent(21);
    let executed = 0;
    for (let i = 0; i < 12 && r.rules.status === 'running'; i++) {
      const { map, strike } = opp.next();
      const d = r.decide('Fight', map, i);
      if (!d.chosen) { r.rules.tick(1500); continue; }
      const exec = r.execute(d.chosen.candidate);
      r.learn(d, exec, resolveExchange(d.chosen.candidate, map, strike, r.rules.cfg));
      executed++;
    }
    assert.equal(r.rules.status, 'won');
    assert.equal(r.growth.memorySize + r.growth.bin.count, executed);
  });
});

describe('Growth Layer: bounded adaptation', () => {
  test('alignment check routes compatible experiences to memory and the rest to the bin', () => {
    const g = new GrowthLayer(KAEDE);
    assert.ok(alignmentScore(KAEDE_CORE, 'defensive') > 0.8);
    assert.ok(alignmentScore(KAEDE_CORE, 'aggressive') < 0.3);
    assert.equal(g.record(record('defensive'), KAEDE_CORE).compatible, true);
    assert.equal(g.record(record('aggressive'), KAEDE_CORE).compatible, false);
    assert.equal(g.memorySize, 1);
    assert.equal(g.bin.count, 1);
  });
  test('the Rejection Bin never influences behaviour', () => {
    const g = new GrowthLayer(KAEDE);
    const before = g.blendedBias(KEY, KAEDE_CORE, 0);
    for (let i = 0; i < 5000; i++) g.record(record('aggressive'), KAEDE_CORE);
    assert.equal(g.bin.count, 5000);
    assert.deepEqual(g.blendedBias(KEY, KAEDE_CORE, 0), before);
  });
  test('memory share is hard-capped below 40% no matter how much evidence accrues', () => {
    const g = new GrowthLayer(KAEDE, { ...new GrowthLayer(KAEDE).cfg, capacity: 100_000 });
    for (let i = 0; i < 50_000; i++) g.record(record('feint', i), KAEDE_CORE);
    const b = g.blendedBias(KEY, KAEDE_CORE, 50_000);
    assert.ok(b.memoryShare < 0.4 && b.memoryShare > 0.39, `memoryShare ${b.memoryShare}`);
    assert.ok(b.coreShare > 0.6);
    // tilt is real but bounded: feint rose from 0.1875 toward 1.0, by at most 0.4 × (1 − 0.1875)
    assert.ok(b.dist.feint! > 0.1875 && b.dist.feint! < 0.1875 + 0.4 * (1 - 0.1875) + 1e-9);
    // and the dominant core trait still dominates
    assert.ok(b.dist.defensive! > b.dist.aggressive!);
  });
  test('memory cannot create behaviour outside the identity’s support', () => {
    const core = { defensive: 0.7, feint: 0.3 };
    const g = new GrowthLayer(burnIdentity({ ...KAEDE_SPEC, dispositions: { [KEY]: core } }));
    for (let i = 0; i < 1000; i++) {
      g.record(record('aggressive', i), core);
      g.record(record('feint', i), core);
    }
    const b = g.blendedBias(KEY, core, 1000);
    assert.equal(b.dist.aggressive, undefined);
    assert.equal(b.dist.dynamic, undefined);
  });
  test('older experiences count for less (temporal decay)', () => {
    const g = new GrowthLayer(KAEDE);
    for (let i = 0; i < 40; i++) g.record(record('feint', 0), KAEDE_CORE);
    const day = 24 * 3600 * 1000;
    const fresh = g.blendedBias(KEY, KAEDE_CORE, 0).memoryShare;
    const old = g.blendedBias(KEY, KAEDE_CORE, 90 * day).memoryShare;
    assert.ok(old < fresh * 0.1, `${old} vs ${fresh}`);
  });
  test('growth never touches the Core Identity', () => {
    const before = KAEDE.checksum;
    const g = new GrowthLayer(KAEDE);
    for (let i = 0; i < 500; i++) g.record(record('defensive', i), KAEDE_CORE);
    verifyIdentity(KAEDE);
    assert.equal(KAEDE.checksum, before);
  });
});

describe('Sleep/Dive', () => {
  const replay = () => ['parry_high', 'thrust', 'side_slide'].map((id) => ({ primitive: id, trajectory: instantiate(prim(id), { ...params, counter: true }, 0).trajectory }));

  test('lowers tracking cost, stays inside gain bounds, only motor params change', () => {
    const cur = factoryMotorParams();
    const { params: next, report } = sleepDive(replay(), cur, { seed: 1, variationsPerJoint: 40 });
    assert.ok(report.costAfter < report.costBefore);
    assert.ok(report.jointsImproved > 0);
    assert.ok(report.microSimulations > 500);
    for (const j of JOINTS) {
      const f = factoryGains(j);
      for (const k of ['kp', 'ki', 'kd'] as const) {
        assert.ok(next[j][k] >= f[k] * GAIN_BOUNDS.min - 1e-12 && next[j][k] <= f[k] * GAIN_BOUNDS.max + 1e-12);
      }
    }
    assert.deepEqual(Object.keys(next).sort(), [...JOINTS].sort());
  });
  test('dream content is wiped on wake and the cycle is reproducible', () => {
    const a = sleepDive(replay(), factoryMotorParams(), { seed: 9, variationsPerJoint: 20 });
    const b = sleepDive(replay(), factoryMotorParams(), { seed: 9, variationsPerJoint: 20 });
    assert.ok(a.report.dreamCharsWiped > 0);
    assert.deepEqual(a.params, b.params);
  });
  test('only runs on the charger', () => {
    const r = robot();
    assert.throws(() => r.sleep(1), /charger/);
    r.sensors = { ...NO_SENSORS, chargerDetected: true };
    assert.doesNotThrow(() => r.sleep(1));
  });
  test('personality is untouched by many sleep cycles', () => {
    const r = robot();
    r.sensors = { ...NO_SENSORS, chargerDetected: true };
    const { map } = new ScriptedOpponent(3).next();
    const styleBefore = JSON.stringify(r.decide('Fight', map, 0).trace.core);
    for (let n = 0; n < 3; n++) r.sleep(n);
    assert.equal(JSON.stringify(r.decide('Fight', map, 0).trace.core), styleBefore);
    verifyIdentity(r.identity);
  });
});

describe('Haptics (§3.5)', () => {
  test('heartbeat rises with exertion and slows when defeated', () => {
    const r = new GameRulebook();
    const idle = hapticsFor(r, 'Idle').heartbeatBpm;
    const calm = hapticsFor(r, 'Fight').heartbeatBpm;
    r.stamina = 10;
    const tired = hapticsFor(r, 'Fight').heartbeatBpm;
    assert.ok(idle < calm && calm < tired);
    r.status = 'defeated';
    assert.ok(hapticsFor(r, 'Fight').heartbeatBpm < idle);
  });
  test('pulse waveform is bounded', () => {
    for (let t = 0; t < 2000; t += 7) {
      const p = heartbeatPulse(t, 80);
      assert.ok(p >= 0 && p <= 1);
    }
  });
});

test('safety limits mirror the spec', () => {
  assert.equal(SAFETY_LIMITS.watchdogTimeoutMs, 50);
  assert.ok(STAND && makePose());
});
