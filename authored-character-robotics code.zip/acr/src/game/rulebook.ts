import type { ResponseClass } from '../mind/coreIdentity';

/**
 * Game Rulebook (paper §2.2) — the central governing logic. HP, stamina and win/loss are plain state
 * with hard-coded rules; the robot does not "feel" tired, its stamina pool is depleted, and actions
 * it cannot afford are rejected here, before they ever reach the motion planner.
 */
export type Command = 'Fight' | 'Greet' | 'Idle';

export interface CommandSpec {
  domain: 'combat' | 'social' | 'none';
  /** Candidate mix (relative counts) the Simulation Engine must generate for this command. */
  mix: Partial<Record<ResponseClass, number>>;
}

export const COMMANDS: Record<Command, CommandSpec> = {
  // 300 aggressive / 400 defensive / 200 feints / 100 dynamic — paper §2.4 step 2
  Fight: { domain: 'combat', mix: { aggressive: 300, defensive: 400, feint: 200, dynamic: 100 } },
  Greet: { domain: 'social', mix: { warm: 500, teasing: 250, indifferent: 250 } },
  Idle: { domain: 'none', mix: {} },
};

export type WinCondition =
  | { type: 'first_to_hits'; hits: number }
  | { type: 'last_standing' }
  | { type: 'time_limit'; ms: number };

export interface RulebookConfig {
  maxHp: number;
  maxStamina: number;
  staminaRegenPerS: number;
  damage: { hit: number; counter: number };
  win: WinCondition[];
}

export const DEFAULT_RULES: RulebookConfig = {
  maxHp: 100,
  maxStamina: 100,
  staminaRegenPerS: 12,
  damage: { hit: 10, counter: 14 },
  win: [{ type: 'first_to_hits', hits: 3 }, { type: 'last_standing' }],
};

export type MatchStatus = 'running' | 'won' | 'lost' | 'draw' | 'defeated';

export interface ExchangeOutcome {
  robotHit: boolean;
  takenHit: boolean;
  dealt: number;
  taken: number;
  tags: string[];
}

export class GameRulebook {
  hp: number;
  stamina: number;
  opponentHp: number;
  hits = { robot: 0, opponent: 0 };
  elapsedMs = 0;
  status: MatchStatus = 'running';

  constructor(readonly cfg: RulebookConfig = DEFAULT_RULES) {
    this.hp = cfg.maxHp;
    this.opponentHp = cfg.maxHp;
    this.stamina = cfg.maxStamina;
  }

  /** The gate every candidate passes before the motion planner sees it. */
  admit(staminaCost: number): { ok: true } | { ok: false; reason: 'match_over' | 'stamina' } {
    if (this.status !== 'running') return { ok: false, reason: 'match_over' };
    if (staminaCost > this.stamina) return { ok: false, reason: 'stamina' };
    return { ok: true };
  }

  spend(cost: number): void {
    this.stamina = Math.max(0, this.stamina - cost);
  }

  tick(dtMs: number): void {
    this.elapsedMs += dtMs;
    this.stamina = Math.min(this.cfg.maxStamina, this.stamina + (this.cfg.staminaRegenPerS * dtMs) / 1000);
    this.evaluate();
  }

  apply(o: ExchangeOutcome): void {
    if (o.robotHit) { this.opponentHp = Math.max(0, this.opponentHp - o.dealt); this.hits.robot++; }
    if (o.takenHit) { this.hp = Math.max(0, this.hp - o.taken); this.hits.opponent++; }
    this.evaluate();
  }

  private evaluate(): void {
    if (this.status !== 'running') return;
    if (this.hp <= 0) { this.status = 'defeated'; return; }
    for (const c of this.cfg.win) {
      if (c.type === 'first_to_hits') {
        if (this.hits.robot >= c.hits && this.hits.robot >= this.hits.opponent) { this.status = 'won'; return; }
        if (this.hits.opponent >= c.hits) { this.status = 'lost'; return; }
      } else if (c.type === 'last_standing') {
        if (this.opponentHp <= 0) { this.status = 'won'; return; }
      } else if (this.elapsedMs >= c.ms) {
        this.status = this.hp > this.opponentHp ? 'won' : this.hp < this.opponentHp ? 'lost' : 'draw';
        return;
      }
    }
  }
}
