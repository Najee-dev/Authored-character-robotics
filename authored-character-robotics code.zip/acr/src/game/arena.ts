import { Rng } from '../motion';
import type { Candidate } from '../mind/primitives';
import { ENGAGEMENT_TAIL_MS, ENGAGE_M, OPEN_ARENA, distanceAt, type SpatialMap, type Zone } from '../mind/spatial';
import type { ExchangeOutcome, RulebookConfig } from './rulebook';

/** A scripted opposing strike: where it lands in time and which zone it targets. */
export interface Strike {
  impactMs: number;
  zone: Zone;
  damage: number;
}

/** Deterministic toy-scale opponent: varies its starting distance and approach speed, strikes high or low. */
export class ScriptedOpponent {
  private rng: Rng;
  constructor(seed: number, private holding = 'wooden_sword') {
    this.rng = new Rng(seed);
  }

  next(walls: SpatialMap['walls'] = OPEN_ARENA): { map: SpatialMap; strike: Strike } {
    const zone: Zone = this.rng.next() < 0.5 ? 'high' : 'low';
    const distanceM = this.rng.range(0.7, 0.99);
    const closingMps = this.rng.range(0.5, 0.9);
    const map: SpatialMap = {
      opponent: { distanceM, closingMps, holding: this.holding, hostile: true, weaponZone: zone },
      walls,
      poseStable: true,
    };
    return { map, strike: { impactMs: ((distanceM - ENGAGE_M) / closingMps) * 1000, zone, damage: 12 } };
  }
}

/** Deterministic exchange resolution used by the demo and tests (the physical world stand-in). */
export function resolveExchange(c: Candidate, map: SpatialMap, strike: Strike, rules: RulebookConfig): ExchangeOutcome {
  const tags: string[] = [];
  let robotHit = false;
  let cancelled = false;
  let parried = false;
  let evaded = false;

  if (c.attack && distanceAt(map, c.peakMs) <= c.reachM && c.peakMs <= strike.impactMs + ENGAGEMENT_TAIL_MS) {
    robotHit = true;
    tags.push('strike_landed');
    if (c.peakMs <= strike.impactMs - 30) { cancelled = true; tags.push('opponent_interrupted'); }
  }
  if (c.cls === 'defensive') {
    const tol = c.zone === 'any' ? 130 : 90;
    const zoneOk = c.zone === 'any' || c.zone === strike.zone;
    if (zoneOk && Math.abs(c.peakMs - strike.impactMs) <= tol) {
      parried = true;
      tags.push('parried');
      if (c.counter) { robotHit = true; tags.push('riposte_landed'); }
    }
  }
  const moved = Math.hypot(c.displacement.x, c.displacement.y);
  if (c.cls === 'dynamic' && moved >= 0.05 && c.peakMs <= strike.impactMs - 50 && c.peakMs >= strike.impactMs - 450) {
    evaded = true;
    tags.push('evaded');
  }
  const takenHit = !(cancelled || parried || evaded);
  if (takenHit) tags.push('took_hit');
  return {
    robotHit,
    takenHit,
    dealt: robotHit ? (parried && c.counter ? rules.damage.counter : rules.damage.hit) : 0,
    taken: takenHit ? strike.damage : 0,
    tags,
  };
}
