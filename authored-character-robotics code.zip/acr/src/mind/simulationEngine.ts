import { Rng, clamp } from '../motion';
import type { ResponseClass } from './coreIdentity';
import { BY_CLASS, instantiate, sampleParams, type Candidate } from './primitives';
import { ENGAGEMENT_TAIL_MS, clearanceAfter, distanceAt, type SpatialMap, type Threat } from './spatial';

/**
 * Simulation Engine (paper §4.2.2): sample ~1,000 candidate plans from the motion-primitive library
 * in the proportions the Game Rulebook asks for. Pure function of (mix, count, seeded RNG).
 */
export function generateCandidates(mix: Partial<Record<ResponseClass, number>>, total: number, rng: Rng): Candidate[] {
  const entries = Object.entries(mix) as [ResponseClass, number][];
  const sum = entries.reduce((s, [, n]) => s + n, 0);
  const out: Candidate[] = [];
  let assigned = 0;
  entries.forEach(([cls, n], i) => {
    const count = i === entries.length - 1 ? total - assigned : Math.round((total * n) / sum);
    assigned += count;
    for (let k = 0; k < count; k++) {
      const def = rng.pick(BY_CLASS[cls]);
      out.push(instantiate(def, sampleParams(def, rng), out.length));
    }
  });
  return out;
}

/**
 * Spatial-awareness relevance of a candidate (paper §2.4 step 4): does this action meet the incoming
 * threat in time and in the right zone, is a strike in reach, does a move head toward open space?
 */
export function situationalFit(c: Candidate, map: SpatialMap, threat: Threat | null, traits: { openSpaceBias: number; counterBias: number }): number {
  let fit = 1;
  const moved = Math.hypot(c.displacement.x, c.displacement.y);
  if (threat) {
    const dt = c.peakMs - threat.impactMs;
    switch (c.cls) {
      case 'defensive': {
        const tol = c.zone === 'any' ? 130 : 90;
        const timing = Math.exp(-0.5 * (dt / tol) ** 2);
        const zoneOk = !threat.zone || c.zone === 'any' || c.zone === threat.zone ? 1 : 0.15;
        fit = Math.max(0.02, timing * zoneOk) * (c.counter ? 1 + 0.6 * traits.counterBias : 1);
        break;
      }
      case 'dynamic':
        fit = moved >= 0.05 ? (dt <= -50 && dt >= -450 ? 1 : 0.3) : 0.5;
        break;
      case 'aggressive': {
        const inReach = distanceAt(map, c.peakMs) <= c.reachM && dt <= ENGAGEMENT_TAIL_MS;
        fit = inReach ? (dt <= -30 ? 1 : 0.6) : 0.15; // lands first, or trades blows, or whiffs
        break;
      }
      case 'feint':
        fit = 0.8; // a feint does not stop an incoming strike
        break;
      default:
        break;
    }
  }
  if (moved > 0) {
    const clearance = clamp(clearanceAfter(map.walls, c.displacement) / 1.0, 0, 1);
    fit *= 1 + traits.openSpaceBias * (clearance - 0.5);
  }
  return fit;
}
