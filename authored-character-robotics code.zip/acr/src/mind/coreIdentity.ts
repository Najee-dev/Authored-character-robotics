/**
 * Read-only Core Identity — the "Bedrock Soul" (paper §4.2.1, §5.2 option 1).
 *
 * The pre-authored backstory is compiled into Conditional Probability Tables: for each situational
 * context, a distribution over response classes. `burnIdentity` validates, canonicalises, deep-freezes
 * and checksums the spec; `verifyIdentity` is the boot-time ROM integrity check. Nothing in the
 * runtime has a code path that mutates an identity.
 */

export type ResponseClass = 'aggressive' | 'defensive' | 'feint' | 'dynamic' | 'warm' | 'teasing' | 'indifferent';
export const COMBAT_CLASSES: readonly ResponseClass[] = ['aggressive', 'defensive', 'feint', 'dynamic'];
export const SOCIAL_CLASSES: readonly ResponseClass[] = ['warm', 'teasing', 'indifferent'];
export const RESPONSE_CLASSES: readonly ResponseClass[] = [...COMBAT_CLASSES, ...SOCIAL_CLASSES];

export type Distribution = Partial<Record<ResponseClass, number>>;

export interface SemanticEntry {
  category: 'weapon' | 'obstacle' | 'surface' | 'prop' | 'agent';
  friction?: number;
}

export interface CharacterSpec {
  name: string;
  /** Authored provenance. Documentation only — never consulted at runtime. */
  backstory: readonly string[];
  /** Context key → distribution. Keys run general → specific, e.g. "combat", "combat/close", "combat/close/armed". */
  dispositions: Record<string, Distribution>;
  /** 0..1 preference for open space over confined corners (paper §4.2.1 "Spatial Context"). */
  openSpaceBias: number;
  /** 0..1 preference for answering a successful parry with a riposte (a counter-fighter's signature). */
  counterBias: number;
  /** Semantic knowledge of the physical world: what objects are and how they behave. */
  semantics: Record<string, SemanticEntry>;
}

export interface BurnedIdentity {
  readonly spec: CharacterSpec;
  readonly checksum: string;
}

export type Context =
  | { domain: 'combat'; range: 'close' | 'mid' | 'far'; armed: boolean }
  | { domain: 'social'; relation: 'friendly' | 'unknown' };

// ---------------------------------------------------------------------------------------------------------------------

export function canonicalJson(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(canonicalJson).join(',')}]`;
  if (v && typeof v === 'object') {
    const o = v as Record<string, unknown>;
    return `{${Object.keys(o).sort().map((k) => `${JSON.stringify(k)}:${canonicalJson(o[k])}`).join(',')}}`;
  }
  return JSON.stringify(v);
}

/** FNV-1a 32-bit. An integrity check against corruption/tampering of the ROM image, not a cryptographic MAC. */
export function fnv1a(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

function deepFreeze<T>(o: T): T {
  if (o && typeof o === 'object' && !Object.isFrozen(o)) {
    Object.freeze(o);
    for (const v of Object.values(o as Record<string, unknown>)) deepFreeze(v);
  }
  return o;
}

function validate(spec: CharacterSpec): void {
  if (!spec.name) throw new Error('identity: name required');
  if (spec.openSpaceBias < 0 || spec.openSpaceBias > 1) throw new Error('identity: openSpaceBias must be in [0,1]');
  if (spec.counterBias < 0 || spec.counterBias > 1) throw new Error('identity: counterBias must be in [0,1]');
  for (const [key, dist] of Object.entries(spec.dispositions)) {
    let sum = 0;
    for (const [cls, p] of Object.entries(dist)) {
      if (!RESPONSE_CLASSES.includes(cls as ResponseClass)) throw new Error(`identity: unknown class "${cls}" in "${key}"`);
      if (p === undefined || p < 0 || p > 1) throw new Error(`identity: p(${cls}) out of range in "${key}"`);
      sum += p;
    }
    if (Math.abs(sum - 1) > 1e-6) throw new Error(`identity: distribution "${key}" sums to ${sum}, expected 1`);
  }
}

/** Manufacturing step: validate → canonicalise → deep-freeze → checksum. */
export function burnIdentity(spec: CharacterSpec): BurnedIdentity {
  validate(spec);
  const canon = JSON.parse(canonicalJson(spec)) as CharacterSpec; // detach from caller-owned objects
  deepFreeze(canon);
  return Object.freeze({ spec: canon, checksum: fnv1a(canonicalJson(canon)) });
}

/** Boot-time integrity check. Throws if the identity does not match its burned checksum. */
export function verifyIdentity(id: BurnedIdentity): void {
  const actual = fnv1a(canonicalJson(id.spec));
  if (actual !== id.checksum) throw new Error(`identity integrity failure: ${actual} != ${id.checksum}`);
}

const ROM_FOOTER = '\n#FNV1A:';
/** Serialise to the image that would be flashed to read-only memory. */
export function toRomImage(id: BurnedIdentity): string {
  return canonicalJson(id.spec) + ROM_FOOTER + id.checksum;
}
export function loadRomImage(image: string): BurnedIdentity {
  const i = image.lastIndexOf(ROM_FOOTER);
  if (i < 0) throw new Error('ROM image: missing footer');
  const body = image.slice(0, i);
  const sum = image.slice(i + ROM_FOOTER.length);
  if (fnv1a(body) !== sum) throw new Error('ROM image: checksum mismatch');
  return burnIdentity(JSON.parse(body) as CharacterSpec);
}

// ---------------------------------------------------------------------------------------------------------------------

/** Context keys from most to least specific. */
export function contextKeys(ctx: Context): string[] {
  return ctx.domain === 'combat'
    ? [`combat/${ctx.range}/${ctx.armed ? 'armed' : 'unarmed'}`, `combat/${ctx.range}`, 'combat']
    : [`social/${ctx.relation}`, 'social'];
}

/** Most specific authored disposition for a context; uniform over the domain's classes if none authored. */
export function resolveDisposition(id: BurnedIdentity, ctx: Context): { key: string; dist: Distribution } {
  for (const key of contextKeys(ctx)) {
    const dist = id.spec.dispositions[key];
    if (dist) return { key, dist };
  }
  const classes = ctx.domain === 'combat' ? COMBAT_CLASSES : SOCIAL_CLASSES;
  const dist: Distribution = {};
  for (const c of classes) dist[c] = 1 / classes.length;
  return { key: ctx.domain, dist };
}

/**
 * Candidate weight multiplier for a class: probability relative to a uniform prior over the table's support.
 * (p=0.50 over 4 classes → ×2.0; p=0.125 → ×0.5; uniform → ×1.0.)
 */
export function multiplierFor(coreDist: Distribution, blended: Distribution, cls: ResponseClass): number {
  const support = Object.values(coreDist).filter((p) => (p ?? 0) > 0).length;
  return (blended[cls] ?? 0) * support;
}

export function semanticOf(id: BurnedIdentity, object: string | undefined): SemanticEntry | undefined {
  return object ? id.spec.semantics[object] : undefined;
}
