import { semanticOf, type BurnedIdentity, type Context } from './coreIdentity';

export type Zone = 'high' | 'low';

/** Output of the spatial awareness stack (ultrasonic, IMU, vision) in robot-centred metres. */
export interface SpatialMap {
  opponent?: { distanceM: number; closingMps: number; holding?: string; hostile: boolean; weaponZone?: Zone };
  friendly?: { distanceM: number };
  /** Clearance to the nearest wall in each direction. */
  walls: { front: number; back: number; left: number; right: number };
  poseStable: boolean;
}

export const OPEN_ARENA: SpatialMap['walls'] = { front: 1.5, back: 1.5, left: 1.5, right: 1.5 };

export function deriveContext(domain: 'combat' | 'social', map: SpatialMap, id: BurnedIdentity): Context {
  if (domain === 'social') return { domain, relation: map.friendly ? 'friendly' : 'unknown' };
  const o = map.opponent;
  const d = o?.distanceM ?? Infinity;
  const range = d < 1.0 ? 'close' : d < 2.0 ? 'mid' : 'far';
  // "Armed" comes from the identity's semantic knowledge of the held object, not from a hard-coded list.
  const armed = semanticOf(id, o?.holding)?.category === 'weapon';
  return { domain, range, armed };
}

export interface Threat {
  impactMs: number;
  zone: Zone | null;
}

/** Opponent weapon reach; impact occurs when it closes to this distance. */
export const ENGAGE_M = 0.25;

/** A strike that lands more than this long after the opponent's own strike is outside the exchange (a whiff). */
export const ENGAGEMENT_TAIL_MS = 150;

export function distanceAt(map: SpatialMap, tMs: number): number {
  const o = map.opponent;
  if (!o) return Infinity;
  return Math.max(0, o.distanceM - (o.closingMps * tMs) / 1000);
}

export function threatOf(map: SpatialMap): Threat | null {
  const o = map.opponent;
  if (!o || !o.hostile || o.closingMps <= 0) return null;
  return { impactMs: Math.max(0, ((o.distanceM - ENGAGE_M) / o.closingMps) * 1000), zone: o.weaponZone ?? null };
}

/** Smallest wall clearance (m) after displacing by (x forward, y left). */
export function clearanceAfter(walls: SpatialMap['walls'], disp: { x: number; y: number }): number {
  return Math.min(walls.front - disp.x, walls.back + disp.x, walls.left - disp.y, walls.right + disp.y);
}
