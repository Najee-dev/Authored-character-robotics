import { burnIdentity, type BurnedIdentity, type CharacterSpec, type SemanticEntry } from './coreIdentity';

const WORLD: Record<string, SemanticEntry> = {
  wooden_sword: { category: 'weapon' },
  steel_sword: { category: 'weapon' },
  wall: { category: 'obstacle' },
  floor: { category: 'surface', friction: 0.6 },
  tatami: { category: 'surface', friction: 0.8 },
  training_dummy: { category: 'prop' },
  rival: { category: 'agent' },
};

/** Defensive counter-fighter — the character used in the paper's §2.4 worked example. */
export const KAEDE_SPEC: CharacterSpec = {
  name: 'Kaede',
  backstory: [
    'Trained under a master who taught that the first strike is a confession.',
    'Won her first arena duels by waiting, parrying, and answering with a single clean thrust.',
  ],
  dispositions: {
    combat: { defensive: 0.4, aggressive: 0.2, feint: 0.2, dynamic: 0.2 },
    'combat/close': { defensive: 0.45, aggressive: 0.15, feint: 0.2, dynamic: 0.2 },
    // ×2.0 parry/counter, ×0.5 aggressive (paper §2.4 steps 3)
    'combat/close/armed': { defensive: 0.5, aggressive: 0.125, feint: 0.1875, dynamic: 0.1875 },
    'social/friendly': { warm: 0.6, teasing: 0.3, indifferent: 0.1 },
    social: { warm: 0.4, teasing: 0.2, indifferent: 0.4 },
  },
  openSpaceBias: 0.7,
  counterBias: 0.7,
  semantics: WORLD,
};

/** Aggressive swordsman — the example from paper §4.2.1 (80% aggressive in armed close combat). */
export const RYUU_SPEC: CharacterSpec = {
  name: 'Ryuu',
  backstory: [
    'Grew up in a walled dueling arena where hesitation lost matches.',
    'Never met a fight he did not want to end in the first exchange.',
  ],
  dispositions: {
    combat: { aggressive: 0.5, defensive: 0.2, feint: 0.15, dynamic: 0.15 },
    'combat/close': { aggressive: 0.55, defensive: 0.2, feint: 0.1, dynamic: 0.15 },
    'combat/close/armed': { aggressive: 0.8, defensive: 0.12, feint: 0.04, dynamic: 0.04 },
    'social/friendly': { warm: 0.9, teasing: 0.05, indifferent: 0.05 },
    social: { warm: 0.5, teasing: 0.2, indifferent: 0.3 },
  },
  openSpaceBias: 0.8,
  counterBias: 0.25,
  semantics: WORLD,
};

export const KAEDE: BurnedIdentity = burnIdentity(KAEDE_SPEC);
export const RYUU: BurnedIdentity = burnIdentity(RYUU_SPEC);
