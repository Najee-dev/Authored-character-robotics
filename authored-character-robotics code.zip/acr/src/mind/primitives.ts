import { READY, STAND, type Pose } from '../spec';
import { buildTrajectory, type Rng, type Step, type Trajectory } from '../motion';
import type { ResponseClass } from './coreIdentity';
import type { Zone } from './spatial';

/**
 * Pre-authored, parameterised movement templates (paper §4.2.2). Candidates are sampled from this
 * library; nothing here is learned. Durations are in ms at speed 1.0 and scale by 1/speed.
 */
export interface Params {
  speed: number; // time scale (>1 = faster)
  reach: number; // amplitude / extension 0.6..1
  aim: number; // -1..1 lateral / blade-angle offset
  delayMs: number; // wait before moving (timing)
  counter: boolean; // parries only: follow with a riposte
}

export interface Candidate {
  id: number;
  primitive: string;
  cls: ResponseClass;
  params: Params;
  trajectory: Trajectory;
  /** Time (ms from start) of the action's decisive moment: strike apex, parry contact, slide end… */
  peakMs: number;
  staminaCost: number;
  zone?: Zone | 'any';
  counter: boolean;
  attack: boolean;
  reachM: number;
  displacement: { x: number; y: number };
}

interface Built {
  steps: Step[];
  peakStep: number;
  displacement?: { x: number; y: number };
  reachM?: number;
}
type Timer = (ms: number) => number;

export interface PrimitiveDef {
  id: string;
  cls: ResponseClass;
  staminaBase: number;
  zone?: Zone | 'any';
  attack?: boolean;
  canCounter?: boolean;
  base?: Pose;
  build(p: Params, d: Timer): Built;
}

/** Absolute leg pose, both legs. */
const legs = (h: number, k: number, a: number): Partial<Pose> => ({
  l_hip_pitch: h, r_hip_pitch: h, l_knee: k, r_knee: k, l_ankle_pitch: a, r_ankle_pitch: a,
});
/**
 * Leg change relative to the fight stance, with the ankle trimmed so the CoM stays near the foot centre
 * (ankle strategy). `lean` 0..1 leaves part of the CoM shift uncompensated for a forward-committed lunge.
 */
const lunge = (dh = -10, dk = 10, lean = 0.5): Partial<Pose> => {
  const balance = -0.6 * dh + 0.5 * dk; // from the hip/knee/ankle CoM coefficients in spec.ts
  return legs(READY.l_hip_pitch + dh, READY.l_knee + dk, Math.min(42, READY.l_ankle_pitch + lean * balance));
};
const twist = (deg: number): Partial<Pose> => ({ l_hip_yaw: deg, r_hip_yaw: deg });
const sgn = (x: number): number => (x >= 0 ? 1 : -1);

export const PRIMITIVES: readonly PrimitiveDef[] = [
  // ── aggressive ───────────────────────────────────────────────────────────────────────────────────
  {
    id: 'slash', cls: 'aggressive', staminaBase: 14, attack: true,
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(380), { r_shoulder_pitch: 85 + 40 * p.reach, r_elbow: 95, r_shoulder_roll: 30 + 10 * p.aim, ...twist(12 * p.reach) }],
        [d(420), { r_shoulder_pitch: 40, r_elbow: 35, r_shoulder_roll: 20 + 10 * p.aim, ...twist(-14 * p.reach) }],
        [d(380), {}],
      ],
      peakStep: 2, reachM: 0.12 + 0.13 * p.reach,
    }),
  },
  {
    id: 'thrust', cls: 'aggressive', staminaBase: 12, attack: true,
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(340), { r_shoulder_pitch: 60, r_elbow: 105, r_shoulder_roll: 10 + 8 * p.aim }],
        [d(380), { r_shoulder_pitch: 75 + 15 * p.reach, r_elbow: 105 - 80 * p.reach, r_shoulder_roll: 10 + 8 * p.aim, ...lunge() }],
        [d(380), {}],
      ],
      peakStep: 2, reachM: 0.16 + 0.14 * p.reach,
    }),
  },
  {
    id: 'overhead_cleave', cls: 'aggressive', staminaBase: 22, attack: true,
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(480), { r_shoulder_pitch: 120 + 40 * p.reach, r_elbow: 70, r_shoulder_roll: 25 }],
        [d(480), { r_shoulder_pitch: 25, r_elbow: 40, ...lunge(-8, 6) }],
        [d(420), {}],
      ],
      peakStep: 2, reachM: 0.14 + 0.13 * p.reach,
    }),
  },
  // ── defensive ────────────────────────────────────────────────────────────────────────────────────
  {
    id: 'parry_high', cls: 'defensive', staminaBase: 8, zone: 'high', canCounter: true,
    build: (p, d) => {
      const steps: Step[] = [
        [p.delayMs, {}],
        [d(240), { r_shoulder_pitch: 105, r_elbow: 55 + 10 * p.aim, r_shoulder_roll: 22 + 12 * p.aim, l_shoulder_pitch: 40 }],
      ];
      if (p.counter) steps.push([d(320), { r_shoulder_pitch: 82, r_elbow: 15, r_shoulder_roll: 15, ...lunge() }]);
      steps.push([d(320), {}]);
      return { steps, peakStep: 1, reachM: p.counter ? 0.28 : 0 };
    },
  },
  {
    id: 'parry_low', cls: 'defensive', staminaBase: 9, zone: 'low', canCounter: true,
    build: (p, d) => {
      const steps: Step[] = [
        [p.delayMs, {}],
        [d(260), { r_shoulder_pitch: 35, r_elbow: 45 + 10 * p.aim, r_shoulder_roll: 38 + 10 * p.aim, ...lunge(-4, 10) }],
      ];
      if (p.counter) steps.push([d(320), { r_shoulder_pitch: 60, r_elbow: 12, ...lunge() }]);
      steps.push([d(320), {}]);
      return { steps, peakStep: 1, reachM: p.counter ? 0.26 : 0 };
    },
  },
  {
    id: 'block_wide', cls: 'defensive', staminaBase: 12, zone: 'any',
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(380), { r_shoulder_pitch: 88, r_elbow: 90, l_shoulder_pitch: 80, l_elbow: 90, l_shoulder_roll: 15, r_shoulder_roll: 12 }],
        [d(320), {}],
      ],
      peakStep: 1,
    }),
  },
  // ── feints ───────────────────────────────────────────────────────────────────────────────────────
  {
    id: 'feint_slash', cls: 'feint', staminaBase: 6,
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(260), { r_shoulder_pitch: 105, r_elbow: 90 }],
        [d(220), { r_shoulder_pitch: 75, r_elbow: 70 }],
        [d(260), {}],
      ],
      peakStep: 2,
    }),
  },
  {
    id: 'probe_thrust', cls: 'feint', staminaBase: 4,
    build: (p, d) => ({
      steps: [[p.delayMs, {}], [d(280), { r_shoulder_pitch: 76 + 6 * p.reach, r_elbow: 60 }], [d(260), {}]],
      peakStep: 1,
    }),
  },
  {
    id: 'fake_step', cls: 'feint', staminaBase: 3,
    build: (p, d) => ({
      steps: [[p.delayMs, {}], [d(300), lunge(-8, 8)], [d(300), {}]],
      peakStep: 1, displacement: { x: 0.03 * p.reach, y: 0 },
    }),
  },
  // ── dynamic ──────────────────────────────────────────────────────────────────────────────────────
  {
    id: 'side_slide', cls: 'dynamic', staminaBase: 8,
    build: (p, d) => {
      const s = sgn(p.aim);
      return {
        steps: [
          [p.delayMs, {}],
          [d(520), { l_hip_roll: 14 * s, r_hip_roll: 14 * s, ...lunge(0, 10) }],
          [d(520), {}],
        ],
        peakStep: 1, displacement: { x: 0, y: 0.12 * s },
      };
    },
  },
  {
    id: 'backstep', cls: 'dynamic', staminaBase: 6,
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(460), lunge(6, -10)],
        [d(400), {}],
      ],
      peakStep: 1, displacement: { x: -0.1 * p.reach, y: 0 },
    }),
  },
  {
    id: 'pivot_spin', cls: 'dynamic', staminaBase: 9,
    build: (p, d) => {
      const yaw = 15 + 45 * p.reach; // >45° exceeds the hip-yaw hard stop → rejected by the Physics Proxy
      return {
        steps: [[p.delayMs, {}], [d(600), { ...twist(yaw), head_yaw: 0.8 * yaw }], [d(500), {}]],
        peakStep: 1,
      };
    },
  },
  {
    id: 'takedown_sweep', cls: 'dynamic', staminaBase: 20,
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(520), { ...lunge(-(6 + 4 * p.reach), 10 + 6 * p.reach, 1), r_shoulder_pitch: 30, r_elbow: 30 }],
        [d(520), {}],
      ],
      peakStep: 1, displacement: { x: 0.04, y: 0 },
    }),
  },
  {
    id: 'backflip', cls: 'dynamic', staminaBase: 30,
    build: (p, d) => ({
      steps: [
        [p.delayMs, {}],
        [d(260), legs(-70, 100, 20)],
        [d(110), { ...legs(30, 2, -30), r_shoulder_pitch: 150, l_shoulder_pitch: 150 }],
        [d(300), {}],
      ],
      peakStep: 2, displacement: { x: -0.2, y: 0 },
    }),
  },
  // ── social (from a relaxed stance) ──────────────────────────────────────────────────────────────
  {
    id: 'wave', cls: 'warm', staminaBase: 1, base: STAND,
    build: (_p, d) => ({
      steps: [
        [0, {}],
        [d(900), { r_shoulder_pitch: 125, r_elbow: 90, r_shoulder_roll: 30 }],
        [d(300), { r_shoulder_pitch: 125, r_elbow: 50, r_shoulder_roll: 30 }],
        [d(300), { r_shoulder_pitch: 125, r_elbow: 90, r_shoulder_roll: 30 }],
        [d(300), { r_shoulder_pitch: 125, r_elbow: 50, r_shoulder_roll: 30 }],
        [d(500), {}],
      ],
      peakStep: 1,
    }),
  },
  {
    id: 'open_arms', cls: 'warm', staminaBase: 1, base: STAND,
    build: (p, d) => ({
      steps: [
        [0, {}],
        [d(500), { l_shoulder_pitch: 60, r_shoulder_pitch: 60, l_shoulder_roll: 70, r_shoulder_roll: 70, l_elbow: 30, r_elbow: 30, head_yaw: 10 * p.aim }],
        [d(600), { l_shoulder_pitch: 60, r_shoulder_pitch: 60, l_shoulder_roll: 70, r_shoulder_roll: 70, l_elbow: 30, r_elbow: 30, head_yaw: 10 * p.aim }],
        [d(500), {}],
      ],
      peakStep: 1,
    }),
  },
  {
    id: 'poke_taunt', cls: 'teasing', staminaBase: 2, base: STAND,
    build: (p, d) => ({
      steps: [
        [0, {}],
        [d(550), { r_shoulder_pitch: 80, r_elbow: 20, r_shoulder_roll: 15, head_yaw: 30 * sgn(p.aim) }],
        [d(250), { r_shoulder_pitch: 85, r_elbow: 5, r_shoulder_roll: 15, head_yaw: 30 * sgn(p.aim) }],
        [d(200), { r_shoulder_pitch: 80, r_elbow: 20, r_shoulder_roll: 15, head_yaw: 30 * sgn(p.aim) }],
        [d(500), {}],
      ],
      peakStep: 2,
    }),
  },
  {
    id: 'shrug_look_away', cls: 'indifferent', staminaBase: 1, base: STAND,
    build: (p, d) => ({
      steps: [
        [0, {}],
        [d(500), { head_yaw: 60 * sgn(p.aim), l_shoulder_roll: 40, r_shoulder_roll: 40, l_shoulder_pitch: 10, r_shoulder_pitch: 10 }],
        [d(700), {}],
      ],
      peakStep: 1,
    }),
  },
];

export const BY_CLASS: Record<ResponseClass, PrimitiveDef[]> = {
  aggressive: [], defensive: [], feint: [], dynamic: [], warm: [], teasing: [], indifferent: [],
};
for (const p of PRIMITIVES) BY_CLASS[p.cls].push(p);

export function sampleParams(def: PrimitiveDef, rng: Rng): Params {
  const social = def.base === STAND;
  return {
    speed: social ? rng.range(0.8, 1.2) : rng.range(0.7, 1.5),
    reach: rng.range(0.6, 1.0),
    aim: rng.range(-1, 1),
    delayMs: social ? 0 : Math.round(rng.range(0, 1500) / 10) * 10,
    counter: !!def.canCounter && rng.next() < 0.5,
  };
}

export function instantiate(def: PrimitiveDef, p: Params, id: number): Candidate {
  const d: Timer = (ms) => Math.max(1, Math.round(ms / p.speed));
  const b = def.build(p, d);
  const trajectory = buildTrajectory(b.steps, def.base ?? READY);
  let peakMs = 0;
  for (let i = 0; i <= b.peakStep; i++) peakMs += b.steps[i][0];
  const counter = !!def.canCounter && p.counter;
  return {
    id,
    primitive: def.id,
    cls: def.cls,
    params: p,
    trajectory,
    peakMs,
    staminaCost: def.staminaBase * (0.6 + 0.4 * p.speed) * (0.7 + 0.3 * p.reach) + (counter ? 6 : 0),
    zone: def.zone,
    counter,
    attack: !!def.attack,
    reachM: b.reachM ?? 0,
    displacement: b.displacement ?? { x: 0, y: 0 },
  };
}
