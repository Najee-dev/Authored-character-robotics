import { JOINTS, JOINT_SPECS, SAFETY_LIMITS, STANCE } from '../spec';
import { clamp, comOffset, DEG, sampleSeries, type Trajectory } from '../motion';

/**
 * Physics Proxy — a digital twin of the body (paper §4.2.3).
 *
 * Reduced-order model: joint limits, servo speed, inverse-dynamics torque (inertia + damping + support
 * load) and a linear-inverted-pendulum ZMP stability check against the support polygon. It is
 * deliberately MORE conservative than the hardware Safety Veto, so anything the Proxy accepts the
 * Veto will also accept. Replace the coefficients in spec.ts with identified values for a real frame.
 */
export interface PhysicsVerdict {
  feasible: boolean;
  reasons: string[];
  peakVelRatio: number;
  peakTorqueRatio: number;
  /** 1 = ZMP at the polygon centre, 0 = on its edge, <0 = outside. */
  stabilityMargin: number;
  /** 0..1, higher = less torque effort. */
  efficiency: number;
  score: number;
}

export const PROXY_LIMITS = {
  velocity: 0.9, // fraction of servo max speed
  torque: 0.8, // fraction of servo rated torque
  stabilityMargin: 0.1,
  angleMarginDeg: SAFETY_LIMITS.angleMarginDeg + 0.5,
} as const;

const DT_MS = 10;
const DT = DT_MS / 1000;
const ZMP_GAIN = STANCE.comHeightM / STANCE.gravity; // z_c / g

export function evaluate(traj: Trajectory): PhysicsVerdict {
  const series = sampleSeries(traj, DT_MS);
  const n = series.length;
  const reasons: string[] = [];
  let peakVel = 0;
  let peakTorque = 0;
  let sumSq = 0;

  for (const j of JOINTS) {
    const s = JOINT_SPECS[j];
    const th = series.map((p) => p[j] * DEG);
    let limitHit = false;
    let velHit = false;
    let torHit = false;
    for (let k = 0; k < n; k++) {
      const deg = series[k][j];
      if (deg < s.minDeg + PROXY_LIMITS.angleMarginDeg || deg > s.maxDeg - PROXY_LIMITS.angleMarginDeg) limitHit = true;
      const interior = k > 0 && k < n - 1;
      const om = interior ? (th[k + 1] - th[k - 1]) / (2 * DT) : 0;
      const al = interior ? (th[k + 1] - 2 * th[k] + th[k - 1]) / (DT * DT) : 0;
      const tau = s.inertia * al + s.damping * om + s.loadNm * Math.sin(th[k]);
      const vr = Math.abs(om / DEG) / s.maxVelDegS;
      const tr = Math.abs(tau) / s.maxTorqueNm;
      if (vr > peakVel) peakVel = vr;
      if (tr > peakTorque) peakTorque = tr;
      if (vr > PROXY_LIMITS.velocity) velHit = true;
      if (tr > PROXY_LIMITS.torque) torHit = true;
      sumSq += tr * tr;
    }
    if (limitHit) reasons.push(`joint_limit:${j}`);
    if (velHit) reasons.push(`velocity:${j}`);
    if (torHit) reasons.push(`torque:${j}`);
  }

  // ZMP stability (linear inverted pendulum): zmp = com − (z_c/g)·a_com
  const cx: number[] = new Array(n);
  const cy: number[] = new Array(n);
  for (let k = 0; k < n; k++) {
    const c = comOffset(series[k]);
    cx[k] = c.x;
    cy[k] = c.y;
  }
  let margin = 1;
  for (let k = 0; k < n; k++) {
    const interior = k > 0 && k < n - 1;
    const ax = interior ? (cx[k + 1] - 2 * cx[k] + cx[k - 1]) / (DT * DT) : 0;
    const ay = interior ? (cy[k + 1] - 2 * cy[k] + cy[k - 1]) / (DT * DT) : 0;
    const zx = cx[k] - ZMP_GAIN * ax;
    const zy = cy[k] - ZMP_GAIN * ay;
    const m = 1 - Math.max(Math.abs(zx) / STANCE.halfLengthM, Math.abs(zy) / STANCE.halfWidthM);
    if (m < margin) margin = m;
  }
  if (margin < PROXY_LIMITS.stabilityMargin) reasons.push('unstable');

  const msr = sumSq / (n * JOINTS.length);
  const efficiency = 1 / (1 + 40 * msr);
  const score = 0.55 * clamp(margin, 0, 1) + 0.45 * efficiency;
  return { feasible: reasons.length === 0, reasons, peakVelRatio: peakVel, peakTorqueRatio: peakTorque, stabilityMargin: margin, efficiency, score };
}
