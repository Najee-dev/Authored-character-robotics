import { JOINTS, JOINT_SPECS, STANCE, STAND, type JointName, type Pose } from './spec';
import { comOffset, DEG } from './motion';
import { stepJoint, type JointState, type MotorParams } from './motor';

export interface Telemetry {
  angles: Pose; // deg
  torquesNm: Pose;
  tempsC: Pose;
  tiltDeg: number;
}

/** The seam between the architecture and real servos (ESP32 UART bus driver implements this). */
export interface HardwareBus {
  writeFrame(target: Pose): void;
  /** Advance `dtMs` of physical time (simulation); a real driver just waits/returns. */
  step(dtMs: number): void;
  readTelemetry(): Telemetry;
  /** Upload tuned control parameters (only the Sleep/Dive cycle calls this). */
  setMotorParams(m: MotorParams): void;
}

export interface TraceSample {
  tMs: number;
  target: Pose;
  angles: Pose;
  torquesNm: Pose;
}

const SIM_DT_S = 0.002;
const AMBIENT_C = 25;

/** PID-driven rigid-joint simulation with a first-order thermal model. */
export class SimulatedHardware implements HardwareBus {
  motor: MotorParams;
  trace: TraceSample[] | null = null;
  private st = {} as Record<JointName, JointState>;
  private target: Pose;
  private torque = {} as Pose;
  private temp = {} as Pose;
  private t = 0;

  constructor(motor: MotorParams, initial: Pose = STAND) {
    this.motor = motor;
    this.target = { ...initial };
    this.reset(initial);
  }

  reset(pose: Pose): void {
    for (const j of JOINTS) {
      this.st[j] = { th: pose[j] * DEG, om: 0, integ: 0 };
      this.torque[j] = 0;
      this.temp[j] = AMBIENT_C;
    }
    this.target = { ...pose };
  }

  writeFrame(target: Pose): void {
    this.target = target;
  }

  setMotorParams(m: MotorParams): void {
    this.motor = m;
  }

  step(dtMs: number): void {
    const n = Math.max(1, Math.round(dtMs / (SIM_DT_S * 1000)));
    for (const j of JOINTS) {
      const tgt = this.target[j] * DEG;
      let tau = 0;
      for (let i = 0; i < n; i++) {
        tau = stepJoint(this.st[j], j, this.motor[j], tgt, SIM_DT_S);
        this.temp[j] += (0.6 * tau * tau - 0.02 * (this.temp[j] - AMBIENT_C)) * SIM_DT_S;
      }
      this.torque[j] = tau;
    }
    this.t += dtMs;
    if (this.trace) {
      this.trace.push({ tMs: this.t, target: { ...this.target }, angles: this.angles(), torquesNm: { ...this.torque } });
    }
  }

  private angles(): Pose {
    const a = {} as Pose;
    for (const j of JOINTS) a[j] = this.st[j].th / DEG;
    return a;
  }

  readTelemetry(): Telemetry {
    const angles = this.angles();
    const c = comOffset(angles);
    return {
      angles,
      torquesNm: { ...this.torque },
      tempsC: { ...this.temp },
      tiltDeg: Math.atan(Math.hypot(c.x, c.y) / STANCE.comHeightM) / DEG,
    };
  }

  /** Torque ratio helper for diagnostics. */
  torqueRatio(j: JointName): number {
    return Math.abs(this.torque[j]) / JOINT_SPECS[j].maxTorqueNm;
  }
}
