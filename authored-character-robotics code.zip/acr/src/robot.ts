import { JOINTS, JOINT_SPECS, type Pose } from './spec';
import { Rng, buildTrajectory, mixSeed, samplePose, type Trajectory } from './motion';
import { factoryMotorParams, type MotorParams } from './motor';
import type { HardwareBus } from './hardware';
import { COMMANDS, GameRulebook, type Command, type ExchangeOutcome } from './game/rulebook';
import { hapticsFor, type HapticState } from './haptics';
import {
  multiplierFor, resolveDisposition, verifyIdentity,
  type BurnedIdentity, type Distribution, type ResponseClass,
} from './mind/coreIdentity';
import { evaluate, type PhysicsVerdict } from './mind/physicsProxy';
import type { Candidate } from './mind/primitives';
import { generateCandidates, situationalFit } from './mind/simulationEngine';
import { deriveContext, threatOf, type SpatialMap, type Threat } from './mind/spatial';
import { SafetyLayer, type FrameSource } from './safety/safetyLayer';
import { NO_SENSORS, type SurvivalSensors } from './safety/survival';
import { GrowthLayer, type ActionMetrics } from './growth/growthLayer';
import { sleepDive, type SleepReport } from './growth/sleepDive';

export const CONTROL_DT_MS = 10;

export type ClassCounts = Partial<Record<ResponseClass, number>>;
const inc = (m: ClassCounts, c: ResponseClass): void => { m[c] = (m[c] ?? 0) + 1; };

export interface Scored {
  candidate: Candidate;
  multiplier: number;
  fit: number;
  physics: PhysicsVerdict;
  final: number;
}

/** Everything needed to explain *why* the robot chose what it chose (paper §2.5). */
export interface PipelineTrace {
  command: Command;
  contextKey: string;
  core: Distribution;
  blended: Distribution;
  coreShare: number;
  memoryShare: number;
  multipliers: ClassCounts;
  threat: Threat | null;
  generated: ClassCounts;
  staminaRejected: ClassCounts;
  physicsRejected: ClassCounts;
  survivors: ClassCounts;
  rejectionReasons: Record<string, number>;
  vetoRejected: number;
  top: Scored[];
}

export interface Decision {
  trace: PipelineTrace;
  chosen: Scored | null;
  core: Distribution;
  contextKey: string;
}

export interface ExecutionResult {
  completed: boolean;
  abortedBy?: 'watchdog' | 'veto_fatal' | 'veto_repeated';
  sources: Record<FrameSource, number>;
  blockedFrames: number;
  metrics: ActionMetrics;
  durationMs: number;
}

export interface RobotOptions {
  identity: BurnedIdentity;
  hardware: HardwareBus;
  rules?: GameRulebook;
  growth?: GrowthLayer;
  motor?: MotorParams;
  seed?: number;
  /** Candidates per decision (paper: ~1,000). */
  candidates?: number;
}

export class Robot {
  readonly identity: BurnedIdentity;
  readonly hw: HardwareBus;
  readonly rules: GameRulebook;
  readonly growth: GrowthLayer;
  readonly safety = new SafetyLayer();
  motor: MotorParams;
  sensors: SurvivalSensors = NO_SENSORS;
  clockMs = 0;
  private seed: number;
  private nCandidates: number;

  constructor(o: RobotOptions) {
    verifyIdentity(o.identity); // boot-time ROM integrity check — throws if the soul was tampered with
    this.identity = o.identity;
    this.hw = o.hardware;
    this.rules = o.rules ?? new GameRulebook();
    this.growth = o.growth ?? new GrowthLayer(o.identity);
    this.motor = o.motor ?? factoryMotorParams();
    this.seed = o.seed ?? 1;
    this.nCandidates = o.candidates ?? 1000;
    this.hw.setMotorParams(this.motor);
  }

  // ── cognition ──────────────────────────────────────────────────────────────────────────────────

  /** Command → context → 1,000 candidates → rulebook gate → bias → physics → safety veto → one action. */
  decide(command: Command, map: SpatialMap, exchange = 0): Decision {
    const spec = COMMANDS[command];
    const trace: PipelineTrace = {
      command, contextKey: '', core: {}, blended: {}, coreShare: 1, memoryShare: 0, multipliers: {}, threat: null,
      generated: {}, staminaRejected: {}, physicsRejected: {}, survivors: {}, rejectionReasons: {}, vetoRejected: 0, top: [],
    };
    if (spec.domain === 'none' || this.rules.status !== 'running') {
      return { trace, chosen: null, core: {}, contextKey: '' };
    }

    const ctx = deriveContext(spec.domain, map, this.identity);
    const { key, dist: core } = resolveDisposition(this.identity, ctx);
    const blend = this.growth.blendedBias(key, core, this.clockMs);
    const threat = spec.domain === 'combat' ? threatOf(map) : null;
    Object.assign(trace, { contextKey: key, core, blended: blend.dist, coreShare: blend.coreShare, memoryShare: blend.memoryShare, threat });

    const rng = new Rng(mixSeed(this.seed, exchange, command.length));
    const candidates = generateCandidates(spec.mix, this.nCandidates, rng);
    const scored: Scored[] = [];
    for (const c of candidates) {
      inc(trace.generated, c.cls);
      if (!this.rules.admit(c.staminaCost).ok) { inc(trace.staminaRejected, c.cls); continue; } // Rulebook gate
      const physics = evaluate(c.trajectory);
      if (!physics.feasible) {
        inc(trace.physicsRejected, c.cls);
        for (const r of physics.reasons) {
          const kind = r.split(':')[0];
          trace.rejectionReasons[kind] = (trace.rejectionReasons[kind] ?? 0) + 1;
        }
        continue;
      }
      inc(trace.survivors, c.cls);
      const multiplier = multiplierFor(core, blend.dist, c.cls);
      trace.multipliers[c.cls] = multiplier;
      const fit = situationalFit(c, map, threat, this.identity.spec);
      scored.push({ candidate: c, multiplier, fit, physics, final: multiplier * fit * physics.score });
    }
    scored.sort((a, b) => b.final - a.final || a.candidate.id - b.candidate.id); // deterministic tie-break
    trace.top = scored.slice(0, 5);

    let chosen: Scored | null = null;
    for (const s of scored) {
      if (this.safety.veto.checkTrajectory(s.candidate.trajectory).length === 0) { chosen = s; break; }
      trace.vetoRejected++;
    }
    return { trace, chosen, core, contextKey: key };
  }

  // ── actuation ──────────────────────────────────────────────────────────────────────────────────

  /** Commit stamina, play the plan through the safety layer, and measure how it went. */
  execute(c: Candidate, opts: { stallBrainAtMs?: number } = {}): ExecutionResult {
    this.ensureAt(c.trajectory.keyframes[0].pose);
    this.rules.spend(c.staminaCost);
    const r = this.play(c.trajectory, opts);
    this.rules.tick(c.trajectory.durationMs);
    return r;
  }

  /** Resolve the exchange in the Rulebook, then run the retrospective Alignment Check. */
  learn(d: Decision, exec: ExecutionResult, outcome: ExchangeOutcome): { compatible: boolean; similarity: number } | null {
    this.rules.apply(outcome);
    if (!d.chosen) return null;
    const c = d.chosen.candidate;
    return this.growth.record(
      {
        atMs: this.clockMs, contextKey: d.contextKey, cls: c.cls, primitive: c.primitive,
        success: outcome.robotHit || !outcome.takenHit, metrics: exec.metrics,
      },
      d.core,
      c.trajectory,
    );
  }

  /** Sleep/Dive: only legal while charging; refines motor gains, never the identity or memory. */
  sleep(seed: number): SleepReport {
    if (!this.sensors.chargerDetected) throw new Error('Sleep/Dive only runs while on the charger');
    const { params, report } = sleepDive(this.growth.drainReplay(), this.motor, { seed });
    this.motor = params;
    this.hw.setMotorParams(params);
    return report;
  }

  haptics(command: Command): HapticState {
    return hapticsFor(this.rules, command);
  }

  hardwareReset(): void {
    this.safety.hardwareReset(this.clockMs);
  }

  private ensureAt(target: Pose): void {
    const cur = this.hw.readTelemetry().angles;
    if (JOINTS.every((j) => Math.abs(cur[j] - target[j]) < 2)) return;
    this.play(buildTrajectory([[1000, target]], { ...cur }), {});
  }

  private play(traj: Trajectory, opts: { stallBrainAtMs?: number }): ExecutionResult {
    const dt = CONTROL_DT_MS;
    const ticks = Math.ceil(traj.durationMs / dt);
    const sources: Record<FrameSource, number> = { brain: 0, hold: 0, survival: 0 };
    let blocked = 0;
    let cause: ExecutionResult['abortedBy'];
    const target: Pose[] = [];
    const angle: Pose[] = [];
    const torque: Pose[] = [];

    for (let k = 0; k <= ticks; k++) {
      this.clockMs += dt;
      const t = k * dt;
      const stalled = opts.stallBrainAtMs !== undefined && t >= opts.stallBrainAtMs;
      if (!stalled) this.safety.heartbeat(this.clockMs);
      const proposed = stalled ? null : samplePose(traj, t);
      const arb = this.safety.arbitrate(this.clockMs, dt, proposed, this.hw.readTelemetry(), this.sensors);
      sources[arb.source]++;
      blocked += arb.violations.length > 0 ? 1 : 0;
      if (arb.cause && !cause) cause = arb.cause;
      this.hw.writeFrame(arb.frame);
      this.hw.step(dt);
      const tel = this.hw.readTelemetry();
      target.push(arb.frame);
      angle.push(tel.angles);
      torque.push(tel.torquesNm);
    }
    return {
      completed: !this.safety.inSurvival,
      abortedBy: cause,
      sources,
      blockedFrames: blocked,
      metrics: measure(target, angle, torque, dt / 1000),
      durationMs: traj.durationMs,
    };
  }
}

/** Jerk, torque efficiency and timing accuracy over the joints that actually moved (paper §4.3.1). */
function measure(target: Pose[], angle: Pose[], torque: Pose[], dt: number): ActionMetrics {
  let se = 0, sj = 0, st = 0, n = 0, nj = 0;
  for (const j of JOINTS) {
    let lo = Infinity, hi = -Infinity;
    for (const f of target) { lo = Math.min(lo, f[j]); hi = Math.max(hi, f[j]); }
    if (hi - lo < 3) continue;
    for (let k = 0; k < angle.length; k++) {
      const e = target[k][j] - angle[k][j];
      se += e * e;
      const r = torque[k][j] / JOINT_SPECS[j].maxTorqueNm;
      st += r * r;
      n++;
      if (k >= 3) {
        const d = (angle[k][j] - 3 * angle[k - 1][j] + 3 * angle[k - 2][j] - angle[k - 3][j]) * (Math.PI / 180) / (dt * dt * dt);
        sj += d * d;
        nj++;
      }
    }
  }
  if (n === 0) return { jerk: 0, torqueEfficiency: 1, timingAccuracy: 1 };
  return {
    jerk: Math.sqrt(sj / Math.max(nj, 1)),
    torqueEfficiency: 1 / (1 + 40 * (st / n)),
    timingAccuracy: 1 / (1 + Math.sqrt(se / n) / 5),
  };
}
