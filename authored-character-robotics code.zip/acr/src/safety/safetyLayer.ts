import { SAFETY_LIMITS, STAND, type Pose } from '../spec';
import type { Telemetry } from '../hardware';
import { PhysicalSafetyVeto, type Violation } from './veto';
import { SurvivalMatrix, type SurvivalSensors, type SurvivalState } from './survival';

/**
 * Hardware watchdog (paper §4.1.2). If the high-level processor misses its heartbeat for more than
 * `timeoutMs`, control transfers to the Survival Matrix. The trip is LATCHED: only a hardware reset
 * (power cycle / reset pin) clears it — software on the main core cannot.
 */
export class Watchdog {
  tripped = false;
  private last: number;
  constructor(readonly timeoutMs: number = SAFETY_LIMITS.watchdogTimeoutMs, startMs = 0) {
    this.last = startMs;
  }
  kick(nowMs: number): void {
    if (!this.tripped) this.last = nowMs;
  }
  poll(nowMs: number): boolean {
    if (!this.tripped && nowMs - this.last > this.timeoutMs) this.tripped = true;
    return this.tripped;
  }
  hardwareReset(nowMs: number): void {
    this.tripped = false;
    this.last = nowMs;
  }
}

export type FrameSource = 'brain' | 'hold' | 'survival';
export interface Arbitration {
  frame: Pose;
  source: FrameSource;
  violations: Violation[];
  survivalState?: SurvivalState;
  cause?: 'watchdog' | 'veto_fatal' | 'veto_repeated';
}

type Cause = NonNullable<Arbitration['cause']>;

/**
 * The safety layer owns the actuator bus: the cognitive stack can only *propose* frames.
 * Every frame is arbitrated here — brain → veto → servo, or survival matrix if the brain is untrustworthy.
 */
export class SafetyLayer {
  readonly veto = new PhysicalSafetyVeto();
  readonly watchdog = new Watchdog();
  readonly survival = new SurvivalMatrix();
  private lastSafe: Pose | null = null;
  private blocks = 0;
  private latched: Cause | null = null;
  private seeded = false;

  get inSurvival(): boolean {
    return this.watchdog.tripped || this.latched !== null;
  }

  /** Liveness signal from the main core, independent of whether it has a frame ready. */
  heartbeat(nowMs: number): void {
    this.watchdog.kick(nowMs);
  }

  arbitrate(nowMs: number, dtMs: number, proposed: Pose | null, telem: Telemetry, sensors: SurvivalSensors): Arbitration {
    if (!this.lastSafe) this.lastSafe = { ...telem.angles };

    if (this.watchdog.poll(nowMs)) return this.survive(nowMs, dtMs, sensors, 'watchdog', []);
    if (this.latched) return this.survive(nowMs, dtMs, sensors, this.latched, []);
    if (!proposed) return { frame: this.lastSafe, source: 'hold', violations: [] };

    const violations = this.veto.checkFrame(proposed, this.lastSafe, dtMs, telem);
    if (violations.length === 0) {
      this.blocks = 0;
      this.lastSafe = proposed;
      return { frame: proposed, source: 'brain', violations };
    }
    this.blocks++;
    if (violations.some((v) => v.severity === 'fatal')) return this.survive(nowMs, dtMs, sensors, 'veto_fatal', violations);
    if (this.blocks >= SAFETY_LIMITS.maxConsecutiveBlocks) return this.survive(nowMs, dtMs, sensors, 'veto_repeated', violations);
    return { frame: this.lastSafe, source: 'hold', violations };
  }

  private survive(nowMs: number, dtMs: number, sensors: SurvivalSensors, cause: Cause, violations: Violation[]): Arbitration {
    if (cause !== 'watchdog') this.latched = cause;
    if (!this.seeded) {
      this.survival.seed(this.lastSafe ?? STAND);
      this.seeded = true;
    }
    const s = this.survival.step(sensors, nowMs, dtMs);
    this.lastSafe = s.pose;
    return { frame: s.pose, source: 'survival', violations, survivalState: s.state, cause };
  }

  /** Hardware reset line — the only way back from survival. */
  hardwareReset(nowMs: number): void {
    this.watchdog.hardwareReset(nowMs);
    this.latched = null;
    this.blocks = 0;
    this.seeded = false;
    this.lastSafe = null;
  }
}
