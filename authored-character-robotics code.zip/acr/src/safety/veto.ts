import { JOINTS, JOINT_SPECS, SAFETY_LIMITS, STANCE, type JointName, type Pose } from '../spec';
import { comOffset, sampleSeries, type Trajectory } from '../motion';
import type { Telemetry } from '../hardware';

export type VetoCategory = 'mechanical' | 'stability' | 'power_thermal';
export interface Violation {
  category: VetoCategory;
  /** block = refuse this frame/plan; fatal = latch to the Survival Matrix. */
  severity: 'block' | 'fatal';
  joint?: JointName;
  detail: string;
}

/**
 * Physical Safety Veto (paper §4.1.1).
 *
 * Deliberately independent of the cognitive stack: it knows nothing about game state, character or
 * "dangerousness" — a takedown, flip or slide is allowed. It refuses only what would damage the robot,
 * injure a human, or cause unrecoverable instability, using absolute hardware limits from ROM.
 */
export class PhysicalSafetyVeto {
  /** Pre-execution check of an entire planned trajectory. */
  checkTrajectory(traj: Trajectory, dtMs = 10): Violation[] {
    const out: Violation[] = [];
    const series = sampleSeries(traj, dtMs);
    for (let k = 0; k < series.length && out.length < 5; k++) {
      out.push(...this.checkFrame(series[k], k > 0 ? series[k - 1] : null, dtMs, null));
    }
    return out;
  }

  /** Per-frame check applied to every command before it reaches the servo bus. */
  checkFrame(frame: Pose, prev: Pose | null, dtMs: number, telem: Telemetry | null): Violation[] {
    const v: Violation[] = [];
    const m = SAFETY_LIMITS.angleMarginDeg;
    for (const j of JOINTS as readonly JointName[]) {
      const s = JOINT_SPECS[j];
      const a = frame[j];
      if (!Number.isFinite(a)) {
        v.push({ category: 'mechanical', severity: 'fatal', joint: j, detail: 'non-finite command' });
        continue;
      }
      if (a < s.minDeg + m || a > s.maxDeg - m) {
        v.push({ category: 'mechanical', severity: 'block', joint: j, detail: `angle ${a.toFixed(1)}° outside [${s.minDeg}, ${s.maxDeg}]` });
      }
      if (prev && dtMs > 0) {
        const vel = Math.abs(a - prev[j]) / (dtMs / 1000);
        if (vel > s.maxVelDegS * SAFETY_LIMITS.velocityTolerance) {
          v.push({ category: 'mechanical', severity: 'block', joint: j, detail: `commanded ${vel.toFixed(0)}°/s > ${s.maxVelDegS}°/s` });
        }
      }
      if (telem) {
        if (Math.abs(telem.torquesNm[j]) > s.maxTorqueNm * 1.001) {
          v.push({ category: 'power_thermal', severity: 'block', joint: j, detail: 'torque above servo rating' });
        }
        if (telem.tempsC[j] >= SAFETY_LIMITS.maxTempC) {
          v.push({ category: 'power_thermal', severity: 'fatal', joint: j, detail: `temperature ${telem.tempsC[j].toFixed(0)}°C` });
        }
      }
    }
    // Dynamic stability: CoM against the support polygon (generous envelope — only unrecoverable states trip it).
    const c = comOffset(frame);
    const k = SAFETY_LIMITS.stabilityEnvelopeScale;
    if (Math.abs(c.x) > STANCE.halfLengthM * k || Math.abs(c.y) > STANCE.halfWidthM * k) {
      v.push({ category: 'stability', severity: 'block', detail: 'CoM outside stability envelope' });
    }
    if (telem && telem.tiltDeg >= SAFETY_LIMITS.maxTiltDeg) {
      v.push({ category: 'stability', severity: 'fatal', detail: `tilt ${telem.tiltDeg.toFixed(0)}° — unrecoverable` });
    }
    return v;
  }
}
