import { JOINTS, JOINT_SPECS, SIT, STAND, makePose, type Pose } from '../spec';

/**
 * Default Survival Matrix (paper §4.1.3).
 *
 * A tiny state machine that runs with NO access to the cognitive stack's memory: it sees only raw
 * sensor inputs and its own ROM constants. It takes over when the watchdog trips or the veto goes fatal.
 * (On hardware this is the secondary core / separate MCU — see firmware/safety_core.h.)
 */
export type SurvivalState = 'Idle' | 'Follow' | 'Charge' | 'BasicDance';

export interface SurvivalSensors {
  batteryPct: number;
  chargerDetected: boolean;
  /** Nearest beacon/person from the ultrasonic + IR sensors. */
  beacon?: { bearingDeg: number; distanceM: number };
  buttonPressed: boolean;
}

export const NO_SENSORS: SurvivalSensors = { batteryPct: 100, chargerDetected: false, buttonPressed: false };

const LOW_BATTERY_PCT = 15;
const DANCE_MS = 6000;

export class SurvivalMatrix {
  state: SurvivalState = 'Idle';
  private danceUntil = -1;
  private out: Pose = STAND;

  /** Seed the slew limiter with the pose the robot is physically in when control is handed over. */
  seed(pose: Pose): void {
    this.out = { ...pose };
  }

  step(s: SurvivalSensors, nowMs: number, dtMs: number): { state: SurvivalState; pose: Pose } {
    if (s.buttonPressed && this.danceUntil < nowMs) this.danceUntil = nowMs + DANCE_MS;
    const lowBatt = s.batteryPct <= LOW_BATTERY_PCT;
    const beacon = s.beacon;
    const beaconNear = !!beacon && beacon.distanceM >= 0.25 && beacon.distanceM <= 2.0;

    if (s.chargerDetected || lowBatt) this.state = 'Charge';
    else if (nowMs < this.danceUntil) this.state = 'BasicDance';
    else if (beaconNear) this.state = 'Follow';
    else this.state = 'Idle';

    let target: Pose;
    const ph = (nowMs / 1000) * 2 * Math.PI;
    switch (this.state) {
      case 'Charge':
        if (s.chargerDetected) target = SIT;
        else if (beacon && beaconNear) target = this.gait(ph, beacon.bearingDeg); // seek the dock beacon
        else target = STAND;
        break;
      case 'Follow':
        target = this.gait(ph, beacon ? beacon.bearingDeg : 0);
        break;
      case 'BasicDance':
        target = makePose({
          r_shoulder_pitch: 90 + 40 * Math.sin(ph), l_shoulder_pitch: 90 - 40 * Math.sin(ph),
          r_shoulder_roll: 40, l_shoulder_roll: 40, r_elbow: 60, l_elbow: 60,
          l_hip_roll: 8 * Math.sin(ph), r_hip_roll: 8 * Math.sin(ph),
          l_knee: 12, r_knee: 12, l_hip_pitch: -6, r_hip_pitch: -6, l_ankle_pitch: 5, r_ankle_pitch: 5,
          head_yaw: 25 * Math.sin(ph / 2),
        });
        break;
      default: // Idle: relaxed stand with a slow "breathing" sway
        target = makePose({ l_hip_pitch: -2 + 1.5 * Math.sin(ph / 4), r_hip_pitch: -2 + 1.5 * Math.sin(ph / 4) }, STAND);
    }
    this.out = this.slew(target, dtMs);
    return { state: this.state, pose: this.out };
  }

  /** Placeholder visual gait — NOT a validated walking controller. */
  private gait(ph: number, bearingDeg: number): Pose {
    const s = Math.sin(1.2 * ph);
    return makePose({
      l_hip_pitch: -12 + 14 * s, r_hip_pitch: -12 - 14 * s,
      l_knee: 22 + 12 * Math.max(0, s), r_knee: 22 + 12 * Math.max(0, -s),
      l_ankle_pitch: 10, r_ankle_pitch: 10,
      head_yaw: Math.max(-60, Math.min(60, bearingDeg)),
    }, STAND);
  }

  /** Limit per-tick motion to half the servo speed limit so a hand-over never slams the joints. */
  private slew(target: Pose, dtMs: number): Pose {
    const next = {} as Pose;
    for (const j of JOINTS) {
      const maxStep = 0.5 * JOINT_SPECS[j].maxVelDegS * (dtMs / 1000);
      const d = target[j] - this.out[j];
      next[j] = this.out[j] + Math.max(-maxStep, Math.min(maxStep, d));
    }
    return next;
  }
}
