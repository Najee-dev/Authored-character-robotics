import { JOINTS, JOINT_SPECS, type JointName, type Pose } from './spec';

export const DEG = Math.PI / 180;

/** Seeded PRNG (mulberry32). Determinism is a design requirement (paper §2.5): no Math.random anywhere. */
export class Rng {
  private s: number;
  constructor(seed: number) {
    this.s = seed >>> 0;
  }
  next(): number {
    this.s = (this.s + 0x6d2b79f5) >>> 0;
    let t = this.s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(a: number, b: number): number {
    return a + (b - a) * this.next();
  }
  pick<T>(arr: readonly T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
  gauss(): number {
    const u = Math.max(this.next(), 1e-12);
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * this.next());
  }
}

export function mixSeed(...parts: number[]): number {
  let h = 2166136261;
  for (const p of parts) {
    h ^= p >>> 0;
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export const clamp = (x: number, lo: number, hi: number): number => (x < lo ? lo : x > hi ? hi : x);

/** Minimum-jerk blend, 0→1 with zero velocity and acceleration at both ends. */
export function minJerk(u: number): number {
  const c = clamp(u, 0, 1);
  return c * c * c * (10 - 15 * c + 6 * c * c);
}

export interface Keyframe {
  t: number; // ms from start
  pose: Pose;
}
export interface Trajectory {
  keyframes: Keyframe[];
  durationMs: number;
}

export type Step = [durationMs: number, pose: Partial<Pose>];

/** Build a trajectory from [duration, partial pose] steps. Unspecified joints stay at `base`. */
export function buildTrajectory(steps: Step[], base: Pose): Trajectory {
  const keyframes: Keyframe[] = [{ t: 0, pose: base }];
  let t = 0;
  for (const [dur, partial] of steps) {
    if (dur <= 0) continue;
    t += dur;
    const pose = { ...base };
    for (const j of JOINTS) if (partial[j] !== undefined) pose[j] = partial[j] as number;
    keyframes.push({ t, pose });
  }
  return { keyframes, durationMs: t };
}

export function samplePose(traj: Trajectory, tMs: number): Pose {
  const k = traj.keyframes;
  if (tMs <= 0) return k[0].pose;
  const last = k[k.length - 1];
  if (tMs >= last.t) return last.pose;
  let i = 1;
  while (k[i].t < tMs) i++;
  const a = k[i - 1];
  const b = k[i];
  const s = minJerk((tMs - a.t) / (b.t - a.t));
  const out = {} as Pose;
  for (const j of JOINTS) out[j] = a.pose[j] + (b.pose[j] - a.pose[j]) * s;
  return out;
}

/** Uniformly sampled poses from t=0 to ≥ durationMs (the last sample holds the final pose). */
export function sampleSeries(traj: Trajectory, dtMs: number): Pose[] {
  const n = Math.ceil(traj.durationMs / dtMs) + 1;
  const out: Pose[] = new Array(n);
  for (let k = 0; k < n; k++) out[k] = samplePose(traj, k * dtMs);
  return out;
}

/** One joint's reference angle in radians at a fine time step (used by offline tuning). */
export function jointSeriesRad(traj: Trajectory, joint: JointName, dtMs: number): number[] {
  const n = Math.ceil(traj.durationMs / dtMs) + 1;
  const out: number[] = new Array(n);
  for (let k = 0; k < n; k++) out[k] = samplePose(traj, k * dtMs)[joint] * DEG;
  return out;
}

/** Whole-body CoM (m) projected on the ground plane, relative to the foot centre (reduced-order linear model). */
export function comOffset(p: Pose): { x: number; y: number } {
  let x = 0;
  let y = 0;
  for (const j of JOINTS) {
    const s = JOINT_SPECS[j];
    x += s.comX * p[j] * DEG;
    y += s.comY * p[j] * DEG;
  }
  return { x, y };
}
