/**
 * Robot description, safety limits and canonical poses (paper §3, §4.1).
 *
 * This file is the single source of truth: the C++ safety core's limit tables are
 * generated from it (tools/genFirmwareLimits.ts), so the TS reference model and the
 * firmware can never silently disagree.
 *
 * Baseline platform: Tonybot-class 17-DOF humanoid, LX-824HV bus servos (17 kg·cm @ 11.1 V).
 * Inertia / load / CoM coefficients are reduced-order estimates — replace them with values
 * from system identification of the real frame.
 */

export const JOINTS = [
  'head_yaw',
  'l_shoulder_pitch', 'l_shoulder_roll', 'l_elbow',
  'r_shoulder_pitch', 'r_shoulder_roll', 'r_elbow',
  'l_hip_yaw', 'l_hip_roll', 'l_hip_pitch', 'l_knee', 'l_ankle_pitch',
  'r_hip_yaw', 'r_hip_roll', 'r_hip_pitch', 'r_knee', 'r_ankle_pitch',
] as const;

export type JointName = (typeof JOINTS)[number];
/** Joint angles in degrees. */
export type Pose = Record<JointName, number>;

export interface JointSpec {
  minDeg: number;
  maxDeg: number;
  maxVelDegS: number;
  maxTorqueNm: number;
  /** Effective inertia about the joint axis, kg·m². */
  inertia: number;
  /** Viscous damping, N·m·s/rad. */
  damping: number;
  /** Peak gravity/support-load torque, N·m (applied as loadNm·sin θ). */
  loadNm: number;
  /** Whole-body CoM shift per radian of this joint, metres (reduced-order model). */
  comX: number;
  comY: number;
}

const KGCM_TO_NM = 0.0980665;
export const SERVO_STALL_TORQUE_NM = 17 * KGCM_TO_NM; // LX-824HV @ 11.1 V (paper §3.1)

function js(s: Pick<JointSpec, 'minDeg' | 'maxDeg' | 'inertia'> & Partial<JointSpec>): JointSpec {
  return {
    maxVelDegS: 520,
    maxTorqueNm: SERVO_STALL_TORQUE_NM,
    damping: 0.004,
    loadNm: 0,
    comX: 0,
    comY: 0,
    ...s,
  };
}

export const JOINT_SPECS: Record<JointName, JointSpec> = {
  head_yaw:         js({ minDeg: -80, maxDeg: 80,  inertia: 0.0004 }),
  l_shoulder_pitch: js({ minDeg: -90, maxDeg: 170, inertia: 0.0015, loadNm: 0.06, comX: 0.010 }),
  l_shoulder_roll:  js({ minDeg: -10, maxDeg: 120, inertia: 0.0015, loadNm: 0.05, comY: 0.008 }),
  l_elbow:          js({ minDeg: 0,   maxDeg: 140, inertia: 0.0008, loadNm: 0.04, comX: 0.005 }),
  // right arm carries the sword prop → heavier
  r_shoulder_pitch: js({ minDeg: -90, maxDeg: 170, inertia: 0.0060, loadNm: 0.12, comX: 0.012 }),
  r_shoulder_roll:  js({ minDeg: -10, maxDeg: 120, inertia: 0.0040, loadNm: 0.10, comY: -0.010 }),
  r_elbow:          js({ minDeg: 0,   maxDeg: 140, inertia: 0.0030, loadNm: 0.08, comX: 0.007 }),
  l_hip_yaw:        js({ minDeg: -45, maxDeg: 45,  inertia: 0.0060 }),
  l_hip_roll:       js({ minDeg: -35, maxDeg: 35,  inertia: 0.0050, loadNm: 0.35, comY: 0.07 }),
  l_hip_pitch:      js({ minDeg: -90, maxDeg: 60,  inertia: 0.0060, loadNm: 0.50, comX: -0.042 }),
  l_knee:           js({ minDeg: 0,   maxDeg: 130, inertia: 0.0030, loadNm: 0.60, comX: 0.035 }),
  l_ankle_pitch:    js({ minDeg: -45, maxDeg: 45,  inertia: 0.0020, loadNm: 0.40, comX: -0.07 }),
  r_hip_yaw:        js({ minDeg: -45, maxDeg: 45,  inertia: 0.0060 }),
  r_hip_roll:       js({ minDeg: -35, maxDeg: 35,  inertia: 0.0050, loadNm: 0.35, comY: 0.07 }),
  r_hip_pitch:      js({ minDeg: -90, maxDeg: 60,  inertia: 0.0060, loadNm: 0.50, comX: -0.042 }),
  r_knee:           js({ minDeg: 0,   maxDeg: 130, inertia: 0.0030, loadNm: 0.60, comX: 0.035 }),
  r_ankle_pitch:    js({ minDeg: -45, maxDeg: 45,  inertia: 0.0020, loadNm: 0.40, comX: -0.07 }),
};

/** Hardware-level limits (paper §4.1). Mirrored into firmware/limits_generated.h. */
export const SAFETY_LIMITS = {
  watchdogTimeoutMs: 50,
  angleMarginDeg: 1.0,
  velocityTolerance: 1.05,
  maxTempC: 70,
  maxTiltDeg: 35,
  maxConsecutiveBlocks: 3,
  /** Veto tolerates CoM excursions up to this multiple of the support polygon (dynamic moves may transit). */
  stabilityEnvelopeScale: 1.5,
} as const;

/**
 * Support polygon (both feet planted) and CoM height for the linear-inverted-pendulum ZMP check.
 * CoM offsets are absolute (zero pose = CoM over the foot centre); every canonical stance is trimmed
 * with an ankle offset so its static CoM sits near zero.
 */
export const STANCE = { halfLengthM: 0.055, halfWidthM: 0.07, comHeightM: 0.17, gravity: 9.81 } as const;

export function makePose(over: Partial<Pose> = {}, base?: Pose): Pose {
  const out = {} as Pose;
  for (const j of JOINTS) out[j] = over[j] ?? base?.[j] ?? 0;
  return out;
}

/** Relaxed standing pose (social / idle). Nothing sits on a hard stop. */
export const STAND: Pose = makePose({
  l_shoulder_roll: 8, r_shoulder_roll: 8, l_elbow: 10, r_elbow: 10,
  l_knee: 4, r_knee: 4, l_hip_pitch: -2, r_hip_pitch: -2, l_ankle_pitch: 2, r_ankle_pitch: 2,
});

/** Fight stance. All combat trajectories start and end here. */
export const READY: Pose = makePose({
  l_hip_pitch: -10, r_hip_pitch: -10, l_knee: 20, r_knee: 20, l_ankle_pitch: 29.5, r_ankle_pitch: 29.5, // ankle trims the sword-forward CoM to ≈0
  r_shoulder_pitch: 70, r_elbow: 80, r_shoulder_roll: 15,
  l_shoulder_pitch: 20, l_shoulder_roll: 25, l_elbow: 60,
});

/** Charging posture used by the Survival Matrix. */
export const SIT: Pose = makePose({
  l_hip_pitch: -85, r_hip_pitch: -85, l_knee: 90, r_knee: 90,
  l_shoulder_roll: 8, r_shoulder_roll: 8, l_elbow: 10, r_elbow: 10,
});
