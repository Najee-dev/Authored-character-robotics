import { JOINTS, type JointName } from '../spec';
import { Rng, jointSeriesRad } from '../motion';
import { clampGains, simulateTracking, type MotorParams, type PidGains } from '../motor';
import type { ReplayItem } from './growthLayer';

/**
 * Sleep/Dive cycle (paper §4.4): replay the day's actions, run thousands of micro-simulated variations,
 * keep the smoothest/most efficient PID gains.
 *
 * Capability separation is the point: this module imports no identity, no memory log and no rulebook.
 * It can read replayed trajectories and write ONE thing — motor parameters (bounded by GAIN_BOUNDS).
 * "Physical improvement without mental drift."
 */

/** Volatile scratch space for replay narration. Never persisted; wiped on wake. */
export class VolatileDream {
  private lines: string[] = [];
  add(line: string): void {
    this.lines.push(line);
  }
  get residentChars(): number {
    return this.lines.reduce((n, l) => n + l.length, 0);
  }
  wipe(): number {
    const n = this.residentChars;
    for (let i = 0; i < this.lines.length; i++) this.lines[i] = '';
    this.lines.length = 0;
    return n;
  }
}

export interface SleepConfig {
  seed: number;
  variationsPerJoint: number;
  maxReplays: number;
  /** Only tune joints that move at least this far in a replay. */
  minRomDeg: number;
  /** A variation must beat the current gains by this fraction to be adopted. */
  improvement: number;
}

export interface SleepReport {
  replayed: number;
  microSimulations: number;
  jointsImproved: number;
  costBefore: number;
  costAfter: number;
  dreamCharsWiped: number;
}

const TUNE_DT_S = 0.002;

export function sleepDive(day: readonly ReplayItem[], current: MotorParams, cfg: Partial<SleepConfig> & { seed: number }): { params: MotorParams; report: SleepReport } {
  const c: SleepConfig = { variationsPerJoint: 120, maxReplays: 6, minRomDeg: 3, improvement: 0.01, ...cfg };
  const rng = new Rng(c.seed);
  const dream = new VolatileDream();
  const replays = day.slice(-c.maxReplays);
  const next = { ...current } as MotorParams;
  let sims = 0;
  let improved = 0;
  let before = 0;
  let after = 0;
  let wiped = 0;

  try {
    for (const j of JOINTS as readonly JointName[]) {
      const refs: number[][] = [];
      for (const r of replays) {
        const ref = jointSeriesRad(r.trajectory, j, TUNE_DT_S * 1000);
        let lo = Infinity;
        let hi = -Infinity;
        for (const x of ref) { if (x < lo) lo = x; if (x > hi) hi = x; }
        if (((hi - lo) * 180) / Math.PI >= c.minRomDeg) refs.push(ref);
      }
      if (refs.length === 0) continue;

      const meanCost = (g: PidGains): number => {
        let s = 0;
        for (const ref of refs) s += simulateTracking(j, g, ref, TUNE_DT_S).cost;
        sims += refs.length;
        return s / refs.length;
      };

      const cur = current[j];
      const base = meanCost(cur);
      let best = cur;
      let bestCost = base;
      for (let v = 0; v < c.variationsPerJoint; v++) {
        const f = () => Math.min(1.3, Math.max(0.7, 1 + 0.1 * rng.gauss()));
        const cand = clampGains(j, { kp: cur.kp * f(), ki: cur.ki * f(), kd: cur.kd * f() });
        const cost = meanCost(cand);
        if (cost < bestCost) { best = cand; bestCost = cost; }
      }
      const adopt = bestCost < base * (1 - c.improvement);
      if (adopt) { next[j] = best; improved++; }
      before += base;
      after += adopt ? bestCost : base;
      dream.add(`replayed ${refs.length} motions on ${j}: cost ${base.toFixed(3)} → ${(adopt ? bestCost : base).toFixed(3)}`);
    }
  } finally {
    // Wake-up: narrative/dream content never leaves volatile memory.
    wiped = dream.wipe();
  }

  return {
    params: next,
    report: { replayed: replays.length, microSimulations: sims, jointsImproved: improved, costBefore: before, costAfter: after, dreamCharsWiped: wiped },
  };
}
