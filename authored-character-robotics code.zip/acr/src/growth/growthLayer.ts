import type { Trajectory } from '../motion';
import { RESPONSE_CLASSES, type BurnedIdentity, type Distribution, type ResponseClass } from '../mind/coreIdentity';

/**
 * Growth Layer (paper §4.3) — bounded adaptation.
 *
 * Records what happened, checks it retrospectively against the Core Identity, keeps the compatible
 * experiences and bins the rest. Memory can only tilt decisions inside the identity's support and
 * never contributes more than `maxMemoryWeight` (40%) of the final bias. The identity is read-only:
 * this class holds a reference to it for verification and never writes through it.
 */
export interface ActionMetrics {
  jerk: number; // rad/s³ RMS over moving joints
  torqueEfficiency: number; // 0..1
  timingAccuracy: number; // 0..1
}

export interface ActionRecord {
  atMs: number;
  contextKey: string;
  cls: ResponseClass;
  primitive: string;
  success: boolean;
  metrics: ActionMetrics;
}

export interface ReplayItem {
  primitive: string;
  trajectory: Trajectory;
}

export interface GrowthConfig {
  /** Minimum cosine similarity to the identity's bias vector for an experience to be remembered. */
  alignmentThreshold: number;
  /** Hard ceiling on memory's share of the final bias (Core Identity always keeps ≥ 1 − this). */
  maxMemoryWeight: number;
  halfLifeMs: number;
  /** Evidence mass at which memory reaches half of its maximum share. */
  confidenceK: number;
  capacity: number;
  replayCapacity: number;
}

export const DEFAULT_GROWTH: GrowthConfig = {
  alignmentThreshold: 0.3,
  maxMemoryWeight: 0.4,
  halfLifeMs: 14 * 24 * 3600 * 1000,
  confidenceK: 25,
  capacity: 2000,
  replayCapacity: 64,
};

/** Cosine similarity between the one-hot feature vector of the executed class and the bias vector. */
export function alignmentScore(core: Distribution, cls: ResponseClass): number {
  let norm = 0;
  for (const c of RESPONSE_CLASSES) norm += (core[c] ?? 0) ** 2;
  return norm === 0 ? 0 : (core[cls] ?? 0) / Math.sqrt(norm);
}

/** Write-only sink. Nothing in the decision path reads it (paper §4.3.3). */
export class RejectionBin {
  private n = 0;
  private recent: ActionRecord[] = [];
  push(r: ActionRecord): void {
    this.n++;
    this.recent.push(r);
    if (this.recent.length > 32) this.recent.shift();
  }
  get count(): number {
    return this.n;
  }
  /** Diagnostics only. */
  diagnostics(): readonly ActionRecord[] {
    return this.recent;
  }
}

interface MemoryEntry {
  atMs: number;
  key: string;
  cls: ResponseClass;
  weight: number;
}

export interface BlendedBias {
  dist: Distribution;
  coreShare: number;
  memoryShare: number;
}

export class GrowthLayer {
  readonly bin = new RejectionBin();
  private memory: MemoryEntry[] = [];
  private replay: ReplayItem[] = [];

  constructor(readonly identity: BurnedIdentity, readonly cfg: GrowthConfig = DEFAULT_GROWTH) {}

  get memorySize(): number {
    return this.memory.length;
  }

  /** Alignment Check + routing. `core` is the identity distribution that governed the decision. */
  record(rec: ActionRecord, core: Distribution, trajectory?: Trajectory): { compatible: boolean; similarity: number } {
    const similarity = alignmentScore(core, rec.cls);
    const compatible = similarity >= this.cfg.alignmentThreshold;
    if (compatible) {
      this.memory.push({ atMs: rec.atMs, key: rec.contextKey, cls: rec.cls, weight: rec.success ? 1 : 0.5 });
      if (this.memory.length > this.cfg.capacity) this.memory.shift();
    } else {
      this.bin.push(rec);
    }
    if (trajectory) {
      this.replay.push({ primitive: rec.primitive, trajectory });
      if (this.replay.length > this.cfg.replayCapacity) this.replay.shift();
    }
    return { compatible, similarity };
  }

  /** Hand the day's actions to the Sleep/Dive cycle (motor refinement only). */
  drainReplay(): ReplayItem[] {
    const out = this.replay;
    this.replay = [];
    return out;
  }

  private decay(ageMs: number): number {
    return Math.pow(0.5, Math.max(0, ageMs) / this.cfg.halfLifeMs);
  }

  /**
   * Final bias = (1 − λ)·core + λ·memory, with λ = maxMemoryWeight · W/(W + K) < maxMemoryWeight,
   * where W is the decayed, outcome-weighted evidence mass for this context.
   */
  blendedBias(contextKey: string, core: Distribution, nowMs: number): BlendedBias {
    const mass: Partial<Record<ResponseClass, number>> = {};
    let total = 0;
    for (const m of this.memory) {
      if (m.key !== contextKey) continue;
      const w = m.weight * this.decay(nowMs - m.atMs);
      mass[m.cls] = (mass[m.cls] ?? 0) + w;
      total += w;
    }
    if (total <= 0) return { dist: { ...core }, coreShare: 1, memoryShare: 0 };
    const lambda = this.cfg.maxMemoryWeight * (total / (total + this.cfg.confidenceK));
    const dist: Distribution = {};
    for (const c of RESPONSE_CLASSES) {
      const p = (1 - lambda) * (core[c] ?? 0) + lambda * ((mass[c] ?? 0) / total);
      if (p > 0) dist[c] = p;
    }
    return { dist, coreShare: 1 - lambda, memoryShare: lambda };
  }
}
