import type { Command, GameRulebook } from './game/rulebook';

/**
 * Presence cues (paper §3.5): heartbeat, breathing and warmth driven by game state.
 * Outputs are setpoints for the chest vibration actuator, torso breathing actuator and heater.
 */
export interface HapticState {
  heartbeatBpm: number;
  breathPeriodS: number;
  warmthC: number;
}

export function hapticsFor(rules: GameRulebook, command: Command): HapticState {
  if (rules.status === 'defeated') return { heartbeatBpm: 45, breathPeriodS: 5, warmthC: 30 }; // slow bradycardia
  const exertion = command === 'Fight' ? 1 - rules.stamina / rules.cfg.maxStamina : 0;
  const alert = command === 'Fight' ? 95 : 62;
  return {
    heartbeatBpm: Math.round(alert + 60 * exertion),
    breathPeriodS: +(4.0 - 2.4 * (command === 'Fight' ? 0.4 + 0.6 * exertion : 0)).toFixed(2),
    warmthC: 31,
  };
}

/** Lub-dub waveform 0..1 for the chest actuator at time tMs. */
export function heartbeatPulse(tMs: number, bpm: number): number {
  const period = 60000 / bpm;
  const ph = (tMs % period) / period;
  const bump = (c: number, w: number) => Math.exp(-(((ph - c) / w) ** 2));
  return Math.min(1, bump(0.05, 0.04) + 0.6 * bump(0.33, 0.05));
}
