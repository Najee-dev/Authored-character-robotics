import { JOINTS, JOINT_SPECS, type JointName } from './spec';

/**
 * Per-joint PID motor-control parameters — the ONLY thing the Sleep/Dive cycle may change (paper §4.4).
 *
 * Note: stock LX-series bus servos run their own inner position loop, so these gains apply to a software
 * tracking layer / torque-controlled actuators (the tendon, SMA and brushless options in §3.4).
 */
export interface PidGains {
  kp: number;
  ki: number;
  kd: number;
}
export type MotorParams = Record<JointName, PidGains>;

/** Tuned gains may never leave [min, max] × the factory values, so tuning cannot destabilise a joint. */
export const GAIN_BOUNDS = { min: 0.25, max: 4 } as const;

export function factoryGains(j: JointName): PidGains {
  const I = JOINT_SPECS[j].inertia;
  const wn = 25; // rad/s — deliberately conservative factory tune
  const zeta = 0.6;
  return { kp: I * wn * wn, ki: 0.1 * I * wn * wn, kd: 2 * zeta * I * wn };
}

export function factoryMotorParams(): MotorParams {
  const m = {} as MotorParams;
  for (const j of JOINTS) m[j] = factoryGains(j);
  return m;
}

export function clampGains(j: JointName, g: PidGains): PidGains {
  const f = factoryGains(j);
  const c = (x: number, base: number) => Math.min(Math.max(x, base * GAIN_BOUNDS.min), base * GAIN_BOUNDS.max);
  return { kp: c(g.kp, f.kp), ki: c(g.ki, f.ki), kd: c(g.kd, f.kd) };
}

export interface JointState {
  th: number; // rad
  om: number; // rad/s
  integ: number;
}

/** One semi-implicit-Euler step of a PID-driven joint. Returns the applied torque (N·m). */
export function stepJoint(st: JointState, j: JointName, g: PidGains, targetRad: number, dt: number): number {
  const s = JOINT_SPECS[j];
  const e = targetRad - st.th;
  st.integ = Math.min(Math.max(st.integ + e * dt, -0.5), 0.5);
  const u = g.kp * e + g.ki * st.integ - g.kd * st.om;
  const tau = Math.min(Math.max(u, -s.maxTorqueNm), s.maxTorqueNm);
  const acc = (tau - s.damping * st.om - s.loadNm * Math.sin(st.th)) / s.inertia;
  st.om += acc * dt;
  st.th += st.om * dt;
  const lo = (s.minDeg * Math.PI) / 180;
  const hi = (s.maxDeg * Math.PI) / 180;
  if (st.th < lo) { st.th = lo; st.om = 0; }
  else if (st.th > hi) { st.th = hi; st.om = 0; }
  return tau;
}

export interface TrackingScore {
  rmsErrDeg: number;
  jerkRms: number; // rad/s³
  energy: number; // ∫τ² dt
  cost: number;
}

/** Closed-loop simulation of one joint following a reference. Used by Sleep/Dive micro-simulations. */
export function simulateTracking(j: JointName, g: PidGains, refRad: ArrayLike<number>, dt: number): TrackingScore {
  const st: JointState = { th: refRad[0], om: 0, integ: 0 };
  let se = 0;
  let sj = 0;
  let energy = 0;
  let nj = 0;
  let p1 = st.th;
  let p2 = st.th;
  let p3 = st.th;
  for (let k = 0; k < refRad.length; k++) {
    const tau = stepJoint(st, j, g, refRad[k], dt);
    const e = refRad[k] - st.th;
    se += e * e;
    energy += tau * tau * dt;
    const jerk = (st.th - 3 * p1 + 3 * p2 - p3) / (dt * dt * dt);
    sj += jerk * jerk;
    nj++;
    p3 = p2; p2 = p1; p1 = st.th;
  }
  const rmsErrDeg = (Math.sqrt(se / refRad.length) * 180) / Math.PI;
  const jerkRms = Math.sqrt(sj / Math.max(nj, 1));
  return { rmsErrDeg, jerkRms, energy, cost: rmsErrDeg + 0.004 * jerkRms + 10 * energy };
}
